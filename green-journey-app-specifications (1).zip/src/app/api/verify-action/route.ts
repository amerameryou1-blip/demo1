import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, verifiedActions, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { actionType, airportCode, referenceNo, customTitle, pointsOverride, co2Override } = body;
    const userId = "demo-user-1";

    // Determine default values based on action type
    let title = customTitle || "Verified Action";
    let points = pointsOverride || 100;
    let co2Offset = co2Override || 15.0;
    let category = "Digital Verification";

    if (actionType === "boarding_pass") {
      title = customTitle || `Digital Boarding Pass Scan (${airportCode || "DXB"})`;
      points = 150;
      co2Offset = 22.5;
      category = "Digital Boarding Pass";
    } else if (actionType === "digital_receipt") {
      title = customTitle || "Paperless Duty Free Digital Invoice";
      points = 45;
      co2Offset = 1.8;
      category = "Digital Receipt";
    } else if (actionType === "mobile_checkin") {
      title = customTitle || "Paperless Airline Mobile App Check-in";
      points = 60;
      co2Offset = 2.5;
      category = "Mobile Check-in";
    } else if (actionType === "carbon_offset") {
      title = customTitle || "Verified SAF Fuel Carbon Offset Contribution";
      points = 300;
      co2Offset = 75.0;
      category = "Verified Carbon Offset";
    } else if (actionType === "hydration") {
      title = customTitle || `Airport Hydration Water Refill (${airportCode || "DXB"})`;
      points = 30;
      co2Offset = 0.8;
      category = "Hydration Station";
    } else if (actionType === "rail_transit") {
      title = customTitle || "Electric Airport Express Rail Transit";
      points = 90;
      co2Offset = 12.0;
      category = "Airport Rail Transit";
    }

    // Insert verified action record
    const ref = referenceNo || `GJ-${Math.floor(100000 + Math.random() * 900000)}`;
    const [newAction] = await db
      .insert(verifiedActions)
      .values({
        userId,
        title,
        category,
        pointsEarned: points,
        co2OffsetKg: co2Offset,
        status: "Verified",
        airportCode: airportCode || "DXB",
        referenceNo: ref,
        date: new Date(),
      })
      .returning();

    // Fetch existing user to update points and calculate new level
    const [existingUser] = await db.select().from(users).where(eq(users.id, userId));
    const updatedPoints = (existingUser?.greenPoints || 0) + points;
    const updatedCo2 = (existingUser?.co2SavedKg || 0) + co2Offset;
    const updatedPlastic = category === "Hydration Station" ? (existingUser?.plasticAvoidedCount || 0) + 1 : (existingUser?.plasticAvoidedCount || 0);

    // Tier calculation: Bronze (0-1500), Silver (1501-3500), Gold (3501-7500), Platinum (7501+)
    let newTier = existingUser?.tier || "Bronze";
    if (updatedPoints >= 7500) {
      newTier = "Platinum";
    } else if (updatedPoints >= 3500) {
      newTier = "Gold";
    } else if (updatedPoints >= 1500) {
      newTier = "Silver";
    } else {
      newTier = "Bronze";
    }

    await db
      .update(users)
      .set({
        greenPoints: updatedPoints,
        co2SavedKg: updatedCo2,
        plasticAvoidedCount: updatedPlastic,
        tier: newTier,
      })
      .where(eq(users.id, userId));

    // Send notification
    const notificationTitle = `You earned ${points} Green Points!`;
    const notificationMessage = `${title} was successfully verified. Added to your impact score.`;
    await db.insert(notifications).values({
      userId,
      title: notificationTitle,
      message: notificationMessage,
      type: "points",
      read: false,
    });

    if (newTier !== existingUser?.tier) {
      await db.insert(notifications).values({
        userId,
        title: `Congratulations! Promoted to ${newTier} Status!`,
        message: `Your eco-journey reached the ${newTier} tier. Unlocked higher bonus multipliers and VIP lounge privileges!`,
        type: "tier",
        read: false,
      });
    }

    return NextResponse.json({
      success: true,
      action: newAction,
      pointsEarned: points,
      newTotalPoints: updatedPoints,
      tier: newTier,
    });
  } catch (error: any) {
    console.error("POST /api/verify-action error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
