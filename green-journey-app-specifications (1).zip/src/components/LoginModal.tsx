"use client";

import React, { useState } from "react";
import { X, Mail, Lock, User, Plane, CheckCircle2, ShieldAlert, Sparkles, LogIn } from "lucide-react";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  onRefresh: () => void;
}

export default function LoginModal({ isOpen, onClose, user, onRefresh }: LoginModalProps) {
  const [tab, setTab] = useState<"login" | "signup" | "link_airline">("login");
  const [email, setEmail] = useState(user?.email || "sarah.jenkins@greenjourney.com");
  const [password, setPassword] = useState("••••••••");
  const [fullName, setFullName] = useState(user?.name || "Captain Sarah Jenkins");
  const [selectedAirline, setSelectedAirline] = useState("Emirates Skywards");
  const [accountNo, setAccountNo] = useState("EK-882049112");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      if (tab === "link_airline") {
        const res = await fetch("/api/auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: "link_airline",
            airlineName: selectedAirline,
            accountNumber: accountNo,
          }),
        });
        const data = await res.json();
        if (data.success) {
          setMessage(`Successfully linked ${selectedAirline}! Earned +200 Green Points.`);
          onRefresh();
          setTimeout(() => {
            onClose();
          }, 1500);
        } else {
          setMessage(data.error || "Failed to link airline");
        }
      } else {
        const res = await fetch("/api/auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: tab,
            email,
            name: fullName,
          }),
        });
        const data = await res.json();
        if (data.success) {
          setMessage(`Welcome back, ${data.user.name}! Account updated.`);
          onRefresh();
          setTimeout(() => {
            onClose();
          }, 1200);
        }
      }
    } catch (err: any) {
      setMessage("Error processing request");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSocial = async (provider: "google" | "apple") => {
    setLoading(true);
    setMessage(null);
    try {
      const socialName = provider === "google" ? "Sarah (Google Sync)" : "Sarah (Apple ID)";
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: provider,
          email: `${provider}.user@greenjourney.com`,
          name: socialName,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(`Logged in via ${provider === "google" ? "Google" : "Apple"}!`);
        onRefresh();
        setTimeout(() => onClose(), 1000);
      }
    } catch {
      setMessage("Social authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl text-white relative">
        {/* Top Header */}
        <div className="p-6 bg-gradient-to-br from-slate-900 via-emerald-950/40 to-slate-900 border-b border-slate-800 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Plane className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Green Journey Access</h2>
              <p className="text-xs text-emerald-400 font-medium">Passenger Loyalty & Verification</p>
            </div>
          </div>

          {/* Mode Switch Tabs */}
          <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800 mt-4">
            <button
              onClick={() => {
                setTab("login");
                setMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
                tab === "login" ? "bg-emerald-500 text-slate-950 shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setTab("signup");
                setMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
                tab === "signup" ? "bg-emerald-500 text-slate-950 shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Sign Up
            </button>
            <button
              onClick={() => {
                setTab("link_airline");
                setMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
                tab === "link_airline" ? "bg-emerald-500 text-slate-950 shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Link Airline
            </button>
          </div>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {message && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{message}</span>
            </div>
          )}

          {tab === "signup" && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Full Passenger Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Captain Sarah Jenkins"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                />
              </div>
            </div>
          )}

          {tab !== "link_airline" && (
            <>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="sarah@greenjourney.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>
              </div>
            </>
          )}

          {tab === "link_airline" && (
            <>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Select Partner Airline</label>
                <select
                  value={selectedAirline}
                  onChange={(e) => setSelectedAirline(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition cursor-pointer"
                >
                  <option value="Emirates Skywards">Emirates Skywards</option>
                  <option value="Qatar Privilege Club">Qatar Privilege Club</option>
                  <option value="Singapore Airlines KrisFlyer">Singapore Airlines KrisFlyer</option>
                  <option value="British Airways Executive Club">British Airways Executive Club</option>
                  <option value="Lufthansa Miles & More">Lufthansa Miles & More</option>
                  <option value="Delta SkyMiles">Delta SkyMiles</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Frequent Flyer / Member ID</label>
                <input
                  type="text"
                  required
                  value={accountNo}
                  onChange={(e) => setAccountNo(e.target.value)}
                  placeholder="EK-882049112"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Linking earns +200 bonus Green Points and syncs eco-boarding status automatically.</span>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <span>Processing...</span>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>
                  {tab === "login" ? "Sign In to Account" : tab === "signup" ? "Create Free Account" : "Connect Airline Loyalty Account"}
                </span>
              </>
            )}
          </button>

          {tab !== "link_airline" && (
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <p className="text-center text-xs text-slate-400 font-medium">Or quick login with</p>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleQuickSocial("google")}
                  className="py-2.5 px-3 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.3 9 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 10.8 0 12.5s.7 2.8 1.9 5.2l3.7-2.9z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.3-6.4-5.2L1.9 16C3.7 19.7 7.5 23 12 23z"
                    />
                  </svg>
                  <span>Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleQuickSocial("apple")}
                  className="py-2.5 px-3 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current text-white" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.18c.67-.82 1.13-1.96.99-3.1-.98.04-2.18.66-2.88 1.47-.63.73-1.18 1.9-1.03 3.02 1.1.09 2.24-.56 2.92-1.39z" />
                  </svg>
                  <span>Apple ID</span>
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
