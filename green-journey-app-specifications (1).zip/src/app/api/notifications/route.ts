import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { action, notificationId } = await req.json();
    const userId = "demo-user-1";

    if (action === "mark_read" && notificationId) {
      await db.update(notifications).set({ read: true }).where(eq(notifications.id, Number(notificationId)));
      return NextResponse.json({ success: true });
    }

    if (action === "mark_all_read") {
      await db.update(notifications).set({ read: true }).where(eq(notifications.userId, userId));
      return NextResponse.json({ success: true });
    }

    if (action === "clear_all") {
      await db.delete(notifications).where(eq(notifications.userId, userId));
      return NextResponse.json({ success: true });
    }

    if (action === "trigger_demo") {
      const demoTitles = [
        "Extra 50 Green Points credited!",
        "Flight DXB -> SIN offset verified",
        "New Gold Lounge discount available",
        "Weekly Eco Summary: 12kg CO2 reduced",
      ];
      const randomTitle = demoTitles[Math.floor(Math.random() * demoTitles.length)];

      const [newNotif] = await db
        .insert(notifications)
        .values({
          userId,
          title: randomTitle,
          message: "Automatic verification system logged eco activity on your travel route.",
          type: "points",
          read: false,
        })
        .returning();

      return NextResponse.json({ success: true, notification: newNotif });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (error: any) {
    console.error("POST /api/notifications error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
