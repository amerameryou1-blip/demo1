"use client";

import React, { useState } from "react";
import {
  Zap,
  Sparkles,
  CheckCircle2,
  Gift,
  Award,
  Globe,
  Droplet,
  Train,
  Smartphone,
  ShieldCheck,
  ChevronRight,
} from "lucide-react";

interface ChallengesTabProps {
  challenges: any[];
  userChallenges: any[];
  onClaimChallenge: (challengeId: number) => Promise<boolean>;
  onRefresh: () => void;
}

export default function ChallengesTab({
  challenges,
  userChallenges,
  onClaimChallenge,
  onRefresh,
}: ChallengesTabProps) {
  const [claimingId, setClaimingId] = useState<number | null>(null);
  const [claimedNotice, setClaimedNotice] = useState<string | null>(null);

  const handleClaim = async (cid: number, title: string) => {
    setClaimingId(cid);
    setClaimedNotice(null);
    const success = await onClaimChallenge(cid);
    setClaimingId(null);
    if (success) {
      setClaimedNotice(`Claimed bonus points for "${title}"!`);
      onRefresh();
    }
  };

  const getChallengeIcon = (iconName: string) => {
    if (iconName === "Droplets") return Droplet;
    if (iconName === "Smartphone") return Smartphone;
    if (iconName === "Globe") return Globe;
    if (iconName === "Train") return Train;
    return Zap;
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/60 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Sustainability Quests & Badges</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Travel Eco Challenges</h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Complete high-impact flight milestones to claim massive bonus Green Points surge packages and unlock status badges.
          </p>
        </div>

        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-right shrink-0">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Bonus Unlocked</p>
          <p className="text-2xl font-black text-amber-400">+1,950 PTS</p>
        </div>
      </div>

      {claimedNotice && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{claimedNotice}</span>
        </div>
      )}

      {/* Challenges List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {challenges.map((ch) => {
          const uCh = userChallenges.find((uc) => uc.challengeId === ch.id);
          const currentProg = uCh ? uCh.currentProgress : 0;
          const isCompleted = uCh ? uCh.completed : currentProg >= ch.targetCount;
          const isClaimed = uCh && uCh.claimedAt;
          const pct = Math.min(100, Math.round((currentProg / ch.targetCount) * 100));

          const IconComp = getChallengeIcon(ch.iconName);

          return (
            <div
              key={ch.id}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-slate-700 transition space-y-4 flex flex-col justify-between shadow-lg"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                      <IconComp className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                        {ch.category}
                      </span>
                      <h3 className="text-base font-bold text-white">{ch.title}</h3>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-extrabold shrink-0 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    +{ch.bonusPoints} PTS
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{ch.description}</p>

                {/* Progress Bar */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-400">Progress</span>
                    <span className="text-emerald-400">
                      {currentProg} / {ch.targetCount} Flights ({pct}%)
                    </span>
                  </div>

                  <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 rounded-full transition-all duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <div className="text-[11px] text-slate-400">
                  {isClaimed ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Bonus Claimed!
                    </span>
                  ) : isCompleted ? (
                    <span className="text-amber-300 font-bold">Ready to claim bonus!</span>
                  ) : (
                    <span>{ch.targetCount - currentProg} more eco flights remaining</span>
                  )}
                </div>

                {isClaimed ? (
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                    Completed
                  </span>
                ) : (
                  <button
                    onClick={() => handleClaim(ch.id, ch.title)}
                    disabled={claimingId === ch.id || (!isCompleted && currentProg < ch.targetCount)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      isCompleted || currentProg >= ch.targetCount
                        ? "bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-md hover:from-amber-300"
                        : "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed"
                    }`}
                  >
                    {claimingId === ch.id ? (
                      <span>Claiming...</span>
                    ) : (
                      <>
                        <Gift className="w-3.5 h-3.5" />
                        <span>Claim Bonus</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
