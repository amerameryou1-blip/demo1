import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, challenges, userChallenges, notifications } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { challengeId } = await req.json();
    const userId = "demo-user-1";

    const [challenge] = await db.select().from(challenges).where(eq(challenges.id, Number(challengeId)));
    if (!challenge) {
      return NextResponse.json({ success: false, error: "Challenge not found" }, { status: 404 });
    }

    const [userChallenge] = await db
      .select()
      .from(userChallenges)
      .where(and(eq(userChallenges.userId, userId), eq(userChallenges.challengeId, Number(challengeId))));

    if (userChallenge && userChallenge.claimedAt) {
      return NextResponse.json({ success: false, error: "Reward already claimed for this challenge" }, { status: 400 });
    }

    // Update or insert user challenge as completed & claimed
    if (userChallenge) {
      await db
        .update(userChallenges)
        .set({
          currentProgress: challenge.targetCount,
          completed: true,
          claimedAt: new Date(),
        })
        .where(eq(userChallenges.id, userChallenge.id));
    } else {
      await db.insert(userChallenges).values({
        userId,
        challengeId: challenge.id,
        currentProgress: challenge.targetCount,
        completed: true,
        claimedAt: new Date(),
      });
    }

    // Award bonus points to user
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const newTotal = (user?.greenPoints || 0) + challenge.bonusPoints;
    await db.update(users).set({ greenPoints: newTotal }).where(eq(users.id, userId));

    // Create notification
    await db.insert(notifications).values({
      userId,
      title: `Challenge Completed: ${challenge.title}!`,
      message: `You unlocked ${challenge.bonusPoints} bonus Green Points for completing ${challenge.title}.`,
      type: "challenge",
      read: false,
    });

    return NextResponse.json({
      success: true,
      bonusPoints: challenge.bonusPoints,
      newTotalPoints: newTotal,
    });
  } catch (error: any) {
    console.error("POST /api/challenges/claim error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
