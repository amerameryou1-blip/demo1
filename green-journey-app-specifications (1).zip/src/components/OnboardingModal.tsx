"use client";

import React, { useState } from "react";
import { X, ChevronRight, ChevronLeft, Globe, Award, Gift, CheckCircle2, Sparkles } from "lucide-react";

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export default function OnboardingModal({ isOpen, onClose, onComplete }: OnboardingModalProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!isOpen) return null;

  const slides = [
    {
      step: "01",
      icon: Globe,
      color: "from-emerald-500 to-teal-600",
      iconColor: "text-emerald-400",
      title: "Travel Sustainably",
      subtitle: "Fly Cleaner & Greener Every Trip",
      description:
        "Choose eco-friendly flight routes, scan paperless boarding passes, refill at airport hydration stations, and offset flight emissions directly through verified Sustainable Aviation Fuel (SAF) programs.",
      bullets: [
        "Digital paperless check-in & boarding",
        "Direct SAF aviation fuel carbon offsets",
        "Reusable water bottle refills at gate hubs",
      ],
      image: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&q=80&w=800",
    },
    {
      step: "02",
      icon: Award,
      color: "from-teal-500 to-blue-600",
      iconColor: "text-teal-400",
      title: "Earn Green Points",
      subtitle: "Instant Verification for Eco Actions",
      description:
        "Scan QR barcodes on your digital pass or airport receipts. Our real-time verification engine awards instant Green Points for every sustainable choice you make in transit.",
      bullets: [
        "Earn up to 150 points per digital flight pass",
        "Tier bonuses for Bronze, Silver, Gold & Platinum members",
        "Complete weekly challenges for big point surges",
      ],
      image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=800",
    },
    {
      step: "03",
      icon: Gift,
      color: "from-blue-600 to-indigo-600",
      iconColor: "text-blue-400",
      title: "Redeem Premium Rewards",
      subtitle: "Airline Luxury Meets Sustainability",
      description:
        "Exchange your Green Points for premium airline perks including VIP Lounge access vouchers, extra legroom seat upgrades, complimentary in-flight Wi-Fi, and duty-free vouchers.",
      bullets: [
        "First-class airport lounge discounts",
        "High-speed satellite Wi-Fi flight passes",
        "Sync with Emirates, Qatar, Singapore Airlines & more",
      ],
      image: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800",
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl text-white relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Image Container */}
        <div className="relative h-48 sm:h-56 w-full overflow-hidden">
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover transition-all duration-700" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

          {/* Slide Indicator Badge */}
          <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700 text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Step {slide.step} of 03
          </div>
        </div>

        {/* Content Box */}
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl bg-gradient-to-br ${slide.color} shadow-lg shadow-emerald-500/10`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-xs uppercase font-bold tracking-widest text-emerald-400">{slide.subtitle}</p>
              <h2 className="text-2xl font-bold text-white tracking-tight">{slide.title}</h2>
            </div>
          </div>

          <p className="text-slate-300 text-sm leading-relaxed">{slide.description}</p>

          <div className="space-y-2 pt-1">
            {slide.bullets.map((bullet, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs text-slate-200 bg-slate-800/60 p-2.5 rounded-xl border border-slate-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{bullet}</span>
              </div>
            ))}
          </div>

          {/* Dots & Nav */}
          <div className="pt-4 flex items-center justify-between border-t border-slate-800">
            {/* Dots */}
            <div className="flex items-center gap-1.5">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`h-2 rounded-full transition-all cursor-pointer ${
                    currentSlide === index ? "w-6 bg-emerald-400" : "w-2 bg-slate-700 hover:bg-slate-600"
                  }`}
                />
              ))}
            </div>

            {/* Buttons */}
            <div className="flex items-center gap-2">
              {currentSlide > 0 && (
                <button
                  onClick={handlePrev}
                  className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              )}
              <button
                onClick={handleNext}
                className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
              >
                <span>{currentSlide === slides.length - 1 ? "Get Started" : "Next Slide"}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
