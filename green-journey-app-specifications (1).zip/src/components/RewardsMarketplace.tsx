"use client";

import React, { useState } from "react";
import {
  Gift,
  Sparkles,
  Search,
  CheckCircle2,
  Lock,
  QrCode,
  Tag,
  Clock,
  X,
  ArrowRight,
  ShieldCheck,
  Coffee,
  Wifi,
  Armchair,
  ShoppingBag,
  Leaf,
  Wine,
} from "lucide-react";

interface RewardsMarketplaceProps {
  user: any;
  rewards: any[];
  userRewards: any[];
  onRedeemReward: (rewardId: number) => Promise<boolean>;
  onRefresh: () => void;
}

export default function RewardsMarketplace({
  user,
  rewards,
  userRewards,
  onRedeemReward,
  onRefresh,
}: RewardsMarketplaceProps) {
  const [activeTab, setActiveTab] = useState<"catalog" | "vouchers">("catalog");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedReward, setSelectedReward] = useState<any | null>(null);
  const [redeeming, setRedeeming] = useState(false);
  const [redeemSuccess, setRedeemSuccess] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const categories = [
    "All",
    "Café",
    "Duty Free",
    "In-flight Wi-Fi",
    "Seat Selection",
    "Lounge discounts",
    "Eco-friendly products",
  ];

  const userPoints = user?.greenPoints || 0;

  const filteredRewards = rewards.filter((r) => {
    const matchesCat =
      selectedCategory === "All" ||
      r.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      (selectedCategory === "Duty Free" && r.category.includes("Duty-free")) ||
      (selectedCategory === "In-flight Wi-Fi" && r.category.includes("Wi-Fi"));
    const matchesSearch =
      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleRedeemClick = (r: any) => {
    setSelectedReward(r);
    setErrorMsg(null);
    setRedeemSuccess(null);
  };

  const confirmRedeem = async () => {
    if (!selectedReward) return;
    setRedeeming(true);
    setErrorMsg(null);

    const success = await onRedeemReward(selectedReward.id);
    setRedeeming(false);
    if (success) {
      setRedeemSuccess(selectedReward);
      onRefresh();
    } else {
      setErrorMsg("Insufficient points balance or redemption error.");
    }
  };

  const getCategoryIcon = (category: string) => {
    if (category.includes("Café")) return Coffee;
    if (category.includes("Wi-Fi")) return Wifi;
    if (category.includes("Seat")) return Armchair;
    if (category.includes("Duty")) return ShoppingBag;
    if (category.includes("Lounge")) return Wine;
    return Leaf;
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/60 to-blue-950/80 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <Gift className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sustainable Travel Perks Marketplace</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Rewards & Vouchers</h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Redeem your Green Points for premium airport discounts, VIP lounges, seat upgrades, and zero-emission accessories.
          </p>
        </div>

        {/* Tab switch catalog vs my active vouchers */}
        <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab("catalog")}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeTab === "catalog"
                ? "bg-emerald-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Browse Marketplace ({rewards.length})
          </button>
          <button
            onClick={() => setActiveTab("vouchers")}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === "vouchers"
                ? "bg-emerald-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>My Active Vouchers ({userRewards.length})</span>
          </button>
        </div>
      </div>

      {/* CATALOG VIEW */}
      {activeTab === "catalog" && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder="Search rewards, Wi-Fi, seat upgrades, lounges..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition cursor-pointer whitespace-nowrap ${
                    selectedCategory === cat
                      ? "bg-emerald-500 text-slate-950 font-bold shadow"
                      : "bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Reward Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRewards.map((reward) => {
              const IconComp = getCategoryIcon(reward.category);
              const canAfford = userPoints >= reward.pointsRequired;

              return (
                <div
                  key={reward.id}
                  className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden hover:border-slate-700 transition flex flex-col justify-between group shadow-lg"
                >
                  <div>
                    {/* Card Image */}
                    <div className="relative h-44 w-full overflow-hidden bg-slate-950">
                      <img
                        src={reward.imageUrl}
                        alt={reward.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/30 to-transparent" />

                      {/* Badge Discount Tag */}
                      <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-emerald-500 text-slate-950 text-xs font-extrabold uppercase shadow">
                        {reward.discountValue}
                      </div>

                      {/* Category Badge */}
                      <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700 text-slate-300 text-[10px] font-semibold flex items-center gap-1">
                        <IconComp className="w-3 h-3 text-emerald-400" />
                        <span>{reward.category}</span>
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-5 space-y-2">
                      <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition line-clamp-1">
                        {reward.title}
                      </h3>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{reward.description}</p>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="p-5 pt-0 flex items-center justify-between border-t border-slate-800/80 mt-2 pt-4">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold block">Required</span>
                      <div className="flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-base font-black text-emerald-400">
                          {reward.pointsRequired.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">PTS</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleRedeemClick(reward)}
                      disabled={!canAfford}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                        canAfford
                          ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20"
                          : "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                      }`}
                    >
                      {canAfford ? (
                        <>
                          <span>Redeem</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      ) : (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>Need More Pts</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MY ACTIVE VOUCHERS VIEW */}
      {activeTab === "vouchers" && (
        <div className="space-y-4">
          {userRewards.length === 0 ? (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
              <QrCode className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-base font-bold text-white">No Saved Vouchers Yet</p>
              <p className="text-xs text-slate-400">Redeem points in the marketplace to store digital vouchers here.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userRewards.map((voucher) => {
                const matchReward = rewards.find((r) => r.id === voucher.rewardId);
                return (
                  <div
                    key={voucher.id}
                    className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 border border-emerald-500/30 shadow-xl flex items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold">
                          {voucher.status}
                        </span>
                        <span className="text-xs text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" /> Valid 90 days
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-white truncate">
                        {matchReward?.title || "Airport Voucher Pass"}
                      </h3>
                      <div className="p-2 bg-slate-950 rounded-xl border border-slate-800 font-mono text-emerald-400 text-xs font-bold tracking-wider inline-block">
                        Code: {voucher.voucherCode}
                      </div>
                    </div>

                    <div className="w-16 h-16 bg-white p-1.5 rounded-xl shrink-0 flex items-center justify-center shadow">
                      {/* Stylized QR placeholder */}
                      <QrCode className="w-full h-full text-slate-900" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* REDEMPTION MODAL */}
      {selectedReward && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl text-white relative">
            <button
              onClick={() => setSelectedReward(null)}
              className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {!redeemSuccess ? (
              <div>
                <div className="relative h-44 w-full">
                  <img
                    src={selectedReward.imageUrl}
                    alt={selectedReward.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                  <div className="absolute bottom-3 left-4 px-3 py-1 rounded-full bg-emerald-500 text-slate-950 text-xs font-extrabold">
                    {selectedReward.discountValue}
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                      {selectedReward.category}
                    </span>
                    <h2 className="text-xl font-bold text-white">{selectedReward.title}</h2>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{selectedReward.description}</p>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Current Points Balance:</span>
                      <span className="text-white font-bold">{userPoints.toLocaleString()} PTS</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Points Cost:</span>
                      <span className="text-emerald-400 font-bold">
                        -{selectedReward.pointsRequired.toLocaleString()} PTS
                      </span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-slate-800">
                      <span className="text-slate-400">Remaining Balance:</span>
                      <span className="text-white font-black">
                        {(userPoints - selectedReward.pointsRequired).toLocaleString()} PTS
                      </span>
                    </div>
                  </div>

                  {errorMsg && (
                    <p className="text-xs text-rose-400 font-medium p-2 bg-rose-500/10 rounded-xl">{errorMsg}</p>
                  )}

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      onClick={() => setSelectedReward(null)}
                      className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmRedeem}
                      disabled={redeeming}
                      className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition cursor-pointer disabled:opacity-50"
                    >
                      {redeeming ? "Processing..." : "Confirm Redemption"}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center space-y-6">
                <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <span className="text-xs font-bold uppercase text-emerald-400 tracking-wider">Pass Issued</span>
                  <h2 className="text-xl font-bold text-white">Voucher Generated!</h2>
                  <p className="text-xs text-slate-300 max-w-xs mx-auto">
                    Your digital voucher pass for "{selectedReward.title}" is saved in your active wallet. Show code at partner counters.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setSelectedReward(null);
                    setActiveTab("vouchers");
                  }}
                  className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow transition cursor-pointer"
                >
                  View Saved Voucher Pass
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
