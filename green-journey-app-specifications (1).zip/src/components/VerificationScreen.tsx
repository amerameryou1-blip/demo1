"use client";

import React, { useState, useEffect } from "react";
import {
  QrCode,
  CheckCircle2,
  Sparkles,
  Plane,
  ShieldCheck,
  Zap,
  RefreshCw,
  X,
  Upload,
  ArrowRight,
  Award,
} from "lucide-react";

interface VerificationScreenProps {
  isOpen: boolean;
  onClose: () => void;
  onVerifySuccess: (actionType: string, airportCode: string, title: string) => void;
}

export default function VerificationScreen({ isOpen, onClose, onVerifySuccess }: VerificationScreenProps) {
  const [step, setStep] = useState<"scan" | "verifying" | "success">("scan");
  const [verifyingProgress, setVerifyingProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState("Reading QR Barcode...");
  const [selectedPass, setSelectedPass] = useState({
    code: "EK-201-DXB-JFK",
    airline: "Emirates",
    flight: "EK 201",
    from: "DXB",
    to: "JFK",
    passenger: "Captain Sarah Jenkins",
    pts: 150,
  });

  const presetPasses = [
    { code: "EK-201-DXB-JFK", airline: "Emirates", flight: "EK 201", from: "DXB", to: "JFK", passenger: "Sarah Jenkins", pts: 150 },
    { code: "QR-008-DOH-LHR", airline: "Qatar Airways", flight: "QR 008", from: "DOH", to: "LHR", passenger: "Sarah Jenkins", pts: 180 },
    { code: "SQ-321-SIN-CDG", airline: "Singapore Airlines", flight: "SQ 321", from: "SIN", to: "CDG", passenger: "Sarah Jenkins", pts: 200 },
  ];

  if (!isOpen) return null;

  const startVerificationProcess = (passObj: any) => {
    setSelectedPass(passObj);
    setStep("verifying");
    setVerifyingProgress(0);

    const stepsList = [
      { pct: 25, msg: "Reading Barcode & Security Tokens..." },
      { pct: 55, msg: "Connecting to Airline Airport Systems..." },
      { pct: 85, msg: "Calculating Paper Avoided & SAF Offsets..." },
      { pct: 100, msg: "Verification Complete! Awarding Points..." },
    ];

    let currentStepIdx = 0;
    const interval = setInterval(() => {
      if (currentStepIdx < stepsList.length) {
        setVerifyingProgress(stepsList[currentStepIdx].pct);
        setStatusMessage(stepsList[currentStepIdx].msg);
        currentStepIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setStep("success");
          onVerifySuccess("boarding_pass", passObj.from, `Digital Boarding Pass - ${passObj.airline} ${passObj.flight}`);
        }, 600);
      }
    }, 700);
  };

  const resetScanner = () => {
    setStep("scan");
    setVerifyingProgress(0);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl text-white relative">
        {/* Top Header Bar */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-emerald-950/50 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">QR Verification Terminal</h2>
              <p className="text-[10px] text-emerald-400">Scan digital boarding pass or receipt</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Scan Mode */}
        {step === "scan" && (
          <div className="p-6 space-y-6 text-center">
            {/* Camera View Simulation Frame */}
            <div className="relative w-full h-64 bg-slate-950 rounded-2xl border-2 border-dashed border-emerald-500/40 p-4 flex flex-col items-center justify-center overflow-hidden group shadow-inner">
              {/* Laser Scan Animation Line */}
              <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10B981] animate-bounce top-1/2 -translate-y-1/2 pointer-events-none" />

              {/* Corner Bracket Guides */}
              <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-emerald-400" />
              <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-emerald-400" />
              <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-emerald-400" />
              <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-emerald-400" />

              <div className="space-y-2 pointer-events-none z-10">
                <QrCode className="w-16 h-16 text-emerald-400 mx-auto animate-pulse" />
                <p className="text-xs font-bold text-white uppercase tracking-wider">Position QR Code Here</p>
                <p className="text-[11px] text-slate-400">Live camera scanner scanning for IATA barcode...</p>
              </div>
            </div>

            {/* Simulated Preset Boarding Passes */}
            <div className="space-y-3 pt-2 text-left">
              <p className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1">
                <Plane className="w-3.5 h-3.5 text-emerald-400" /> Select Sample Digital Boarding Pass
              </p>

              <div className="space-y-2">
                {presetPasses.map((pass) => (
                  <button
                    key={pass.code}
                    onClick={() => startVerificationProcess(pass)}
                    className="w-full p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500 hover:bg-slate-800/80 transition flex items-center justify-between text-left group cursor-pointer"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{pass.airline}</span>
                        <span className="text-[10px] font-mono text-emerald-400 font-bold">{pass.flight}</span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        {pass.from} → {pass.to} • {pass.passenger}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                        +{pass.pts} PTS
                      </span>
                      <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Verifying Sequence */}
        {step === "verifying" && (
          <div className="p-8 space-y-6 text-center">
            <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-slate-800" />
              <div
                className="absolute inset-0 rounded-full border-4 border-emerald-400 border-t-transparent animate-spin"
              />
              <Plane className="w-8 h-8 text-emerald-400 animate-pulse" />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-bold text-white">Verifying Eco Flight Choice...</h3>
              <p className="text-xs font-medium text-emerald-400">{statusMessage}</p>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2 max-w-xs mx-auto">
              <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                  style={{ width: `${verifyingProgress}%` }}
                />
              </div>
              <p className="text-[10px] text-slate-500 font-mono">{verifyingProgress}% Completed</p>
            </div>
          </div>
        )}

        {/* Step 3: Success Screen */}
        {step === "success" && (
          <div className="p-8 space-y-6 text-center animate-in zoom-in duration-300">
            {/* Confetti Green Icon */}
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-xl shadow-emerald-500/30">
              <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-400" />
              </div>
            </div>

            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase">
                Verification Successful!
              </span>
              <h3 className="text-2xl font-black text-white tracking-tight">
                +{selectedPass.pts} Green Points Awarded!
              </h3>
              <p className="text-xs text-slate-300 max-w-xs mx-auto">
                {selectedPass.airline} flight {selectedPass.flight} verified. Your sustainable travel choice offsetted ~25 kg CO₂.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-left space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Flight Route</span>
                <span className="text-white font-semibold">{selectedPass.from} → {selectedPass.to}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Pass Barcode ID</span>
                <span className="text-mono text-emerald-400 font-semibold">{selectedPass.code}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Eco Benefit</span>
                <span className="text-emerald-300 font-semibold">100% Paperless + SAF Contribution</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={resetScanner}
                className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Scan Another Pass</span>
              </button>
              <button
                onClick={onClose}
                className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition shadow cursor-pointer"
              >
                <span>Done</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
