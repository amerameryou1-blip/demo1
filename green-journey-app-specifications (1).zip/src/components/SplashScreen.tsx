"use client";

import React from "react";
import { Leaf, Plane, ShieldCheck, ArrowRight, Sparkles } from "lucide-react";

interface SplashScreenProps {
  onStart: () => void;
  onOpenOnboarding: () => void;
  onOpenAuth: () => void;
}

export default function SplashScreen({ onStart, onOpenOnboarding, onOpenAuth }: SplashScreenProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-slate-950 via-emerald-950 to-blue-950 text-white p-6 overflow-y-auto">
      {/* Background Glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-md w-full text-center relative z-10 space-y-8 animate-in fade-in zoom-in duration-500 my-auto">
        {/* Luxury Logo Badge */}
        <div className="mx-auto w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-blue-500 p-0.5 shadow-2xl shadow-emerald-500/20">
          <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center relative">
            <Leaf className="w-10 h-10 text-emerald-400 absolute -translate-x-1 -translate-y-1" />
            <Plane className="w-10 h-10 text-blue-300 translate-x-2 translate-y-2 transform -rotate-12 opacity-90" />
          </div>
        </div>

        {/* Title and Tagline */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" /> First Class Eco Travel
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-200 bg-clip-text text-transparent">
            Green Journey
          </h1>
          <p className="text-lg text-emerald-300 font-medium tracking-wide italic">
            “Rewarding Sustainable Travel”
          </p>
          <p className="text-sm text-slate-300 max-w-sm mx-auto font-normal leading-relaxed">
            Scan boarding passes, offset carbon, and earn premium airport & airline rewards across partner global airlines.
          </p>
        </div>

        {/* Feature Pill Indicators */}
        <div className="grid grid-cols-3 gap-2 py-2">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur text-center">
            <p className="text-emerald-400 font-bold text-base">2.8k+</p>
            <p className="text-[11px] text-slate-400">Green Points</p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur text-center">
            <p className="text-blue-400 font-bold text-base">140+ kg</p>
            <p className="text-[11px] text-slate-400">CO₂ Offset</p>
          </div>
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur text-center">
            <p className="text-amber-400 font-bold text-base">Gold Tier</p>
            <p className="text-[11px] text-slate-400">Perks Access</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-2">
          <button
            onClick={onStart}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-blue-600 hover:from-emerald-400 hover:to-blue-500 text-white font-bold text-base shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition transform active:scale-95 cursor-pointer"
          >
            <span>Launch Green Journey Dashboard</span>
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onOpenOnboarding}
              className="py-3 px-4 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-medium text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <span>How It Works</span>
            </button>
            <button
              onClick={onOpenAuth}
              className="py-3 px-4 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-medium text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <span>Login / Sign Up</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-4">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>IATA Verified Sustainable Aviation Protocol Partner</span>
        </div>
      </div>
    </div>
  );
}
