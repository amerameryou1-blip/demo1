#!/bin/bash
echo "============================================="
echo "   BUILDING GREEN JOURNEY ANDROID APP (APK)   "
echo "============================================="

# Ensure Next.js build is generated
echo "[1/3] Building web bundle for Android export..."
npm run build

# Sync Capacitor assets into Android project
echo "[2/3] Syncing Capacitor plugins and assets..."
npx cap sync android

echo "[3/3] Android project ready in ./android folder!"
echo "To run directly on your phone connected via USB debugging:"
echo "1. Connect your Android phone via USB and enable USB Debugging."
echo "2. Run: cd android && ./gradlew assembleDebug"
echo "3. Install APK: adb install app/build/outputs/apk/debug/app-debug.apk"
echo "Or open the ./android folder in Android Studio and click 'Run on Device'."
