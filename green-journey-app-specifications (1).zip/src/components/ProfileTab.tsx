"use client";

import React, { useState } from "react";
import {
  User,
  Plane,
  Award,
  Link,
  Plus,
  Trash2,
  CheckCircle2,
  ShieldCheck,
  QrCode,
  Calendar,
  Sparkles,
  ArrowUpRight,
  RefreshCw,
} from "lucide-react";

interface ProfileTabProps {
  user: any;
  airlineAccounts: any[];
  actions: any[];
  onOpenLinkModal: () => void;
  onUnlinkAirline: (accountId: number) => void;
}

export default function ProfileTab({
  user,
  airlineAccounts,
  actions,
  onOpenLinkModal,
  onUnlinkAirline,
}: ProfileTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<"pass" | "airlines" | "history">("pass");

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Profile Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4 text-center sm:text-left">
          <img
            src={user?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"}
            alt={user?.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-400 shadow-lg"
          />

          <div className="space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className="text-xl font-bold text-white">{user?.name || "Captain Sarah Jenkins"}</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase">
                {user?.tier || "Silver"} Member
              </span>
            </div>
            <p className="text-xs text-slate-400">{user?.email || "sarah.jenkins@greenjourney.com"}</p>
            <p className="text-[11px] text-slate-500 font-mono">Frequent Flyer ID: {user?.frequentFlyerId || "GJ-9824106"}</p>
          </div>
        </div>

        {/* Action Button & Subtabs */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <button
            onClick={onOpenLinkModal}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition shadow cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Link Airline</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex bg-slate-950 p-1.5 rounded-2xl border border-slate-800 max-w-md">
        <button
          onClick={() => setActiveSubTab("pass")}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
            activeSubTab === "pass" ? "bg-emerald-500 text-slate-950 font-bold shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          Digital Pass
        </button>
        <button
          onClick={() => setActiveSubTab("airlines")}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
            activeSubTab === "airlines" ? "bg-emerald-500 text-slate-950 font-bold shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          Linked Airlines ({airlineAccounts.length})
        </button>
        <button
          onClick={() => setActiveSubTab("history")}
          className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
            activeSubTab === "history" ? "bg-emerald-500 text-slate-950 font-bold shadow" : "text-slate-400 hover:text-white"
          }`}
        >
          Points Ledger
        </button>
      </div>

      {/* SUBTAB 1: DIGITAL PASS CARD */}
      {activeSubTab === "pass" && (
        <div className="max-w-xl mx-auto space-y-4">
          <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950 to-blue-950 border border-emerald-500/40 p-6 sm:p-8 shadow-2xl text-white space-y-6 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                <Plane className="w-6 h-6 text-emerald-400" />
                <span className="font-extrabold text-lg tracking-wider text-white">GREEN JOURNEY PASS</span>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-400 text-slate-950 font-black text-xs uppercase shadow">
                {user?.tier || "Silver"} Status
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[10px] uppercase text-slate-400 font-bold">Passenger Name</span>
                <p className="text-base font-bold text-white">{user?.name || "Captain Sarah Jenkins"}</p>
              </div>
              <div>
                <span className="text-[10px] uppercase text-slate-400 font-bold">Green Points Balance</span>
                <p className="text-base font-bold text-emerald-400">{(user?.greenPoints || 2850).toLocaleString()} PTS</p>
              </div>
              <div>
                <span className="text-[10px] uppercase text-slate-400 font-bold">Primary Air Hub</span>
                <p className="text-sm font-semibold text-slate-200">{user?.homeAirport || "DXB - Dubai"}</p>
              </div>
              <div>
                <span className="text-[10px] uppercase text-slate-400 font-bold">CO₂ Footprint Offset</span>
                <p className="text-sm font-semibold text-blue-300">{user?.co2SavedKg || 142.5} kg Offset</p>
              </div>
            </div>

            {/* Barcode Ticket Strips */}
            <div className="p-4 bg-white rounded-2xl text-slate-900 space-y-2 text-center shadow">
              <div className="h-12 w-full bg-[repeating-linear-gradient(90deg,#0f172a,#0f172a_3px,transparent_3px,transparent_7px)] opacity-90" />
              <p className="text-[10px] font-mono font-bold text-slate-700 uppercase tracking-widest">
                *GJ-{user?.frequentFlyerId || "9824106"}-ECO-PASS*
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: LINKED AIRLINES */}
      {activeSubTab === "airlines" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {airlineAccounts.map((acc) => (
              <div
                key={acc.id}
                className="p-5 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex items-center justify-between gap-4 shadow-md"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Plane className="w-4 h-4 text-emerald-400 shrink-0" />
                    <h3 className="text-sm font-bold text-white truncate">{acc.airlineName}</h3>
                  </div>
                  <p className="text-xs text-slate-400 font-mono">Member ID: {acc.accountNumber}</p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 pt-1">
                    <span className="text-emerald-400 font-bold">+{acc.pointsSynced} Pts Synced</span>
                    <span>•</span>
                    <span className="text-slate-300">{acc.status}</span>
                  </div>
                </div>

                <button
                  onClick={() => onUnlinkAirline(acc.id)}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                  title="Unlink Airline"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={onOpenLinkModal}
            className="p-4 rounded-3xl border-2 border-dashed border-slate-800 hover:border-emerald-500/50 w-full text-center text-xs font-bold text-slate-400 hover:text-emerald-400 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Link Emirates, Qatar Airways, Singapore Airlines, Lufthansa & More</span>
          </button>
        </div>
      )}

      {/* SUBTAB 3: POINTS HISTORY LEDGER */}
      {activeSubTab === "history" && (
        <div className="space-y-3">
          {actions.map((act) => (
            <div
              key={act.id}
              className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4"
            >
              <div className="space-y-0.5 min-w-0">
                <p className="text-xs font-bold text-white truncate">{act.title}</p>
                <p className="text-[10px] text-slate-400">
                  {new Date(act.date).toLocaleDateString()} • {act.category} • Ref: {act.referenceNo}
                </p>
              </div>

              <span className="text-xs font-extrabold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20 shrink-0">
                +{act.pointsEarned} PTS
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
