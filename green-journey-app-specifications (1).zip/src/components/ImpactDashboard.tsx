"use client";

import React from "react";
import {
  TrendingUp,
  Leaf,
  Droplet,
  Trash2,
  Award,
  Sparkles,
  Calendar,
  ShieldCheck,
  Zap,
  Globe,
  CheckCircle2,
  Lock,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

interface ImpactDashboardProps {
  user: any;
  actions: any[];
  badges: any[];
  userBadges: any[];
}

export default function ImpactDashboard({
  user,
  actions,
  badges,
  userBadges,
}: ImpactDashboardProps) {
  // Sample chart data for monthly offset trends
  const monthlyImpactData = [
    { month: "Jan", co2: 12.0, points: 240, plastics: 6 },
    { month: "Feb", co2: 18.5, points: 370, plastics: 8 },
    { month: "Mar", co2: 22.0, points: 440, plastics: 10 },
    { month: "Apr", co2: 31.0, points: 620, plastics: 12 },
    { month: "May", co2: 28.0, points: 560, plastics: 11 },
    { month: "Jun", co2: 41.0, points: 820, plastics: 15 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/70 to-teal-950/80 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Environmental Impact Scorecard</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">My Sustainability Impact</h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Track your verified contributions toward carbon reduction, paperless air transit, and plastic-neutral flights.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-center">
            <p className="text-[10px] text-slate-400 uppercase font-bold">Total CO₂ Saved</p>
            <p className="text-2xl font-black text-emerald-400">{user?.co2SavedKg || 142.5} kg</p>
          </div>
          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-center">
            <p className="text-[10px] text-slate-400 uppercase font-bold">Actions Count</p>
            <p className="text-2xl font-black text-blue-400">{actions.length}</p>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CO2 Offset Card */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">CO₂ Footprint Neutralized</span>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Leaf className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-white">{user?.co2SavedKg || 142.5} <span className="text-sm text-emerald-400">kg</span></p>
          <p className="text-[11px] text-slate-400">Equivalent to planting 7 mature pine trees along global flight corridors.</p>
        </div>

        {/* Liters Water Saved Card */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">Liters Water Conserved</span>
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Droplet className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-white">{user?.waterSavedLiters || 320} <span className="text-sm text-blue-400">Liters</span></p>
          <p className="text-[11px] text-slate-400">Saved through hydration refill pods at DXB, DOH & SIN airports.</p>
        </div>

        {/* Single Use Plastic Avoided */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">Plastics Avoided</span>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Trash2 className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-white">{user?.plasticAvoidedCount || 48} <span className="text-sm text-amber-400">Items</span></p>
          <p className="text-[11px] text-slate-400">Single-use cups and plastic shopping bags skipped during journeys.</p>
        </div>

        {/* Total Green Points Earned */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-bold uppercase">Lifetime Green Points</span>
            <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-white">{(user?.greenPoints || 2850).toLocaleString()} <span className="text-sm text-teal-400">PTS</span></p>
          <p className="text-[11px] text-slate-400">Ranked top 5% of sustainable frequent flyers this calendar quarter.</p>
        </div>
      </div>

      {/* Interactive Recharts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly CO2 Savings Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Leaf className="w-4 h-4 text-emerald-400" />
                Monthly CO₂ Offset Trend (kg)
              </h2>
              <p className="text-xs text-slate-400">Carbon offset volume tracked per flight month</p>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
              +45.2% Growth
            </span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyImpactData}>
                <defs>
                  <linearGradient id="colorCo2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
                <YAxis stroke="#64748B" fontSize={12} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0F172A", borderColor: "#334155", borderRadius: "12px", color: "#fff" }}
                />
                <Area type="monotone" dataKey="co2" stroke="#10B981" strokeWidth={3} fillOpacity={1} fill="url(#colorCo2)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly Green Points Accumulation Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-400" />
                Points Earned History
              </h2>
              <p className="text-xs text-slate-400">Monthly breakdown of accumulated Green Points</p>
            </div>
            <span className="text-xs font-bold text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-full border border-blue-500/30">
              820 Max / Mo
            </span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyImpactData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
                <YAxis stroke="#64748B" fontSize={12} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0F172A", borderColor: "#334155", borderRadius: "12px", color: "#fff" }}
                />
                <Bar dataKey="points" fill="#3B82F6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Earned Badges Showcase Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              Sustainability Badges & Milestones
            </h2>
            <p className="text-xs text-slate-400">Collectible badges unlocked by completing eco achievements</p>
          </div>
          <span className="px-3 py-1 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/30 text-xs font-bold">
            {userBadges.length} / {badges.length} Badges Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((badge) => {
            const isUnlocked = userBadges.some((ub) => ub.badgeId === badge.id);

            return (
              <div
                key={badge.id}
                className={`p-4 rounded-2xl border transition flex items-start gap-3 ${
                  isUnlocked
                    ? "bg-gradient-to-br from-slate-950 to-slate-900 border-emerald-500/40 shadow-md"
                    : "bg-slate-950/60 border-slate-800 opacity-60"
                }`}
              >
                <div
                  className={`p-3 rounded-2xl border shrink-0 ${
                    isUnlocked
                      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                      : "bg-slate-800 border-slate-700 text-slate-600"
                  }`}
                >
                  {isUnlocked ? <Award className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
                </div>

                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-xs font-bold text-white truncate">{badge.name}</h3>
                    {isUnlocked && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">{badge.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
