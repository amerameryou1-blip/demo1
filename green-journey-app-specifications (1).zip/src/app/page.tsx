"use client";

import React, { useState, useEffect } from "react";
import HeaderNav from "@/components/HeaderNav";
import SplashScreen from "@/components/SplashScreen";
import OnboardingModal from "@/components/OnboardingModal";
import LoginModal from "@/components/LoginModal";
import HomeDashboard from "@/components/HomeDashboard";
import EarnPointsTab from "@/components/EarnPointsTab";
import VerificationScreen from "@/components/VerificationScreen";
import RewardsMarketplace from "@/components/RewardsMarketplace";
import ChallengesTab from "@/components/ChallengesTab";
import ImpactDashboard from "@/components/ImpactDashboard";
import ProfileTab from "@/components/ProfileTab";
import AirportsMapTab from "@/components/AirportsMapTab";
import NotificationsModal from "@/components/NotificationsModal";
import SettingsModal from "@/components/SettingsModal";
import { Sparkles, Leaf, Plane, QrCode, Smartphone } from "lucide-react";

export default function Home() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("home");

  // Modals visibility
  const [showSplash, setShowSplash] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // App framing toggle (Desktop vs Mobile App Frame)
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  // Fetch application data from backend API
  const fetchData = async () => {
    try {
      const res = await fetch("/api/data");
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (err) {
      console.error("Error loading Green Journey data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handlers for API actions
  const handleVerifySuccess = async (actionType: string, airportCode: string, title: string) => {
    try {
      const res = await fetch("/api/verify-action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ actionType, airportCode, customTitle: title }),
      });
      const json = await res.json();
      if (json.success) {
        fetchData();
      }
    } catch (err) {
      console.error("Verification error:", err);
    }
  };

  const handleRedeemReward = async (rewardId: number): Promise<boolean> => {
    try {
      const res = await fetch("/api/rewards/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rewardId }),
      });
      const json = await res.json();
      return json.success;
    } catch (err) {
      return false;
    }
  };

  const handleClaimChallenge = async (challengeId: number): Promise<boolean> => {
    try {
      const res = await fetch("/api/challenges/claim", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ challengeId }),
      });
      const json = await res.json();
      return json.success;
    } catch (err) {
      return false;
    }
  };

  const handleUnlinkAirline = async (accountId: number) => {
    try {
      await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "unlink_airline", accountId }),
      });
      fetchData();
    } catch (err) {
      console.error("Unlink airline error:", err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "mark_all_read" }),
      });
      fetchData();
    } catch (err) {}
  };

  const handleClearNotifications = async () => {
    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "clear_all" }),
      });
      fetchData();
    } catch (err) {}
  };

  const handleTriggerDemoNotif = async () => {
    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "trigger_demo" }),
      });
      fetchData();
    } catch (err) {}
  };

  const unreadNotificationsCount = data?.notifications
    ? data.notifications.filter((n: any) => !n.read).length
    : 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white space-y-4">
        <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-blue-600 p-0.5 animate-bounce">
          <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
            <Leaf className="w-8 h-8 text-emerald-400" />
          </div>
        </div>
        <p className="text-sm font-semibold text-emerald-400 tracking-wider uppercase animate-pulse">
          Loading Green Journey Experience...
        </p>
      </div>
    );
  }

  const user = data?.user || {};
  const actions = data?.actions || [];
  const rewards = data?.rewards || [];
  const userRewards = data?.userRewards || [];
  const challenges = data?.challenges || [];
  const userChallenges = data?.userChallenges || [];
  const badges = data?.badges || [];
  const userBadges = data?.userBadges || [];
  const notifications = data?.notifications || [];
  const partnerAirports = data?.partnerAirports || [];
  const partnerAirlines = data?.partnerAirlines || [];
  const airlineAccounts = data?.airlineAccounts || [];

  return (
    <div className={`min-h-screen ${darkMode ? "bg-slate-950 text-slate-100" : "bg-slate-100 text-slate-900"} font-sans transition-colors duration-300 antialiased`}>
      {/* Opening Splash Screen overlay */}
      {showSplash && (
        <SplashScreen
          onStart={() => setShowSplash(false)}
          onOpenOnboarding={() => {
            setShowSplash(false);
            setShowOnboarding(true);
          }}
          onOpenAuth={() => {
            setShowSplash(false);
            setShowAuth(true);
          }}
        />
      )}

      {/* Onboarding Slides Modal */}
      <OnboardingModal
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
        onComplete={() => setActiveTab("home")}
      />

      {/* Login & Link Airline Modal */}
      <LoginModal
        isOpen={showAuth}
        onClose={() => setShowAuth(false)}
        user={user}
        onRefresh={fetchData}
      />

      {/* Verification Scanner Screen Modal */}
      <VerificationScreen
        isOpen={showVerification}
        onClose={() => setShowVerification(false)}
        onVerifySuccess={handleVerifySuccess}
      />

      {/* Notifications Drawer */}
      <NotificationsModal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllRead}
        onClearAll={handleClearNotifications}
        onTriggerDemo={handleTriggerDemoNotif}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />

      {/* Main Top Header Navigation */}
      <HeaderNav
        user={user}
        unreadCount={unreadNotificationsCount}
        onOpenNotifications={() => setShowNotifications(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenAuth={() => setShowAuth(true)}
        isMobileFrame={isMobileFrame}
        onToggleFrame={() => setIsMobileFrame(!isMobileFrame)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Content Container Wrapper */}
      <main className="py-6 px-4 sm:px-6 lg:px-8">
        <div className={isMobileFrame ? "max-w-md mx-auto bg-slate-900 border-4 border-slate-800 rounded-[40px] p-4 shadow-2xl overflow-hidden my-4" : "max-w-7xl mx-auto"}>
          
          {/* Active View Switcher */}
          {activeTab === "home" && (
            <HomeDashboard
              user={user}
              actions={actions}
              challenges={challenges}
              userChallenges={userChallenges}
              setActiveTab={setActiveTab}
              onOpenVerification={() => setShowVerification(true)}
              onCompleteMission={(title, pts) => handleVerifySuccess("mobile_checkin", "DXB", title)}
            />
          )}

          {activeTab === "earn" && (
            <EarnPointsTab
              actions={actions}
              onOpenVerification={() => setShowVerification(true)}
              onLogQuickAction={(type, title) => handleVerifySuccess(type, "DXB", title)}
            />
          )}

          {activeTab === "verify" && (
            <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
              <QrCode className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
              <h2 className="text-xl font-bold text-white">Live Barcode & Pass Scanner</h2>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                Launch verification process to scan digital boarding passes or duty free receipts.
              </p>
              <button
                onClick={() => setShowVerification(true)}
                className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg"
              >
                Launch QR Scanner
              </button>
            </div>
          )}

          {activeTab === "rewards" && (
            <RewardsMarketplace
              user={user}
              rewards={rewards}
              userRewards={userRewards}
              onRedeemReward={handleRedeemReward}
              onRefresh={fetchData}
            />
          )}

          {activeTab === "challenges" && (
            <ChallengesTab
              challenges={challenges}
              userChallenges={userChallenges}
              onClaimChallenge={handleClaimChallenge}
              onRefresh={fetchData}
            />
          )}

          {activeTab === "impact" && (
            <ImpactDashboard
              user={user}
              actions={actions}
              badges={badges}
              userBadges={userBadges}
            />
          )}

          {activeTab === "profile" && (
            <ProfileTab
              user={user}
              airlineAccounts={airlineAccounts}
              actions={actions}
              onOpenLinkModal={() => setShowAuth(true)}
              onUnlinkAirline={handleUnlinkAirline}
            />
          )}

          {activeTab === "map" && (
            <AirportsMapTab airports={partnerAirports} airlines={partnerAirlines} />
          )}

        </div>
      </main>

      {/* Mobile Bottom Navigation Bar (Visible on Smartphone screens) */}
      <div className="fixed bottom-0 inset-x-0 z-30 md:hidden bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-2 py-2 flex items-center justify-around text-slate-400">
        {[
          { id: "home", label: "Dashboard", icon: Leaf },
          { id: "earn", label: "Earn", icon: QrCode },
          { id: "rewards", label: "Rewards", icon: Sparkles },
          { id: "map", label: "Airports", icon: Plane },
          { id: "profile", label: "Profile", icon: Smartphone },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl text-[10px] font-semibold transition cursor-pointer ${
                isActive ? "text-emerald-400 bg-emerald-500/10" : "hover:text-white"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
