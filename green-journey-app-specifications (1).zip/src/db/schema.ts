import { pgTable, text, integer, real, boolean, timestamp, serial } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  avatar: text("avatar"),
  tier: text("tier").notNull().default("Silver"), // Bronze, Silver, Gold, Platinum
  greenPoints: integer("green_points").notNull().default(2850),
  co2SavedKg: real("co2_saved_kg").notNull().default(142.5),
  waterSavedLiters: integer("water_saved_liters").notNull().default(320),
  plasticAvoidedCount: integer("plastic_avoided_count").notNull().default(48),
  homeAirport: text("home_airport").notNull().default("DXB - Dubai International"),
  frequentFlyerId: text("frequent_flyer_id").notNull().default("GJ-9824106"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const airlineAccounts = pgTable("airline_accounts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  airlineName: text("airline_name").notNull(),
  airlineCode: text("airline_code").notNull(),
  accountNumber: text("account_number").notNull(),
  status: text("status").notNull().default("Connected"), // Connected, Syncing
  pointsSynced: integer("points_synced").notNull().default(0),
  lastSyncedAt: timestamp("last_synced_at").defaultNow(),
});

export const verifiedActions = pgTable("verified_actions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  category: text("category").notNull(), // Boarding Pass, Digital Receipt, Carbon Offset, Water Bottle, Transit, Mobile Check-in
  pointsEarned: integer("points_earned").notNull(),
  co2OffsetKg: real("co2_offset_kg").notNull().default(0),
  status: text("status").notNull().default("Verified"), // Verified, Pending, Processing
  airportCode: text("airport_code"),
  referenceNo: text("reference_no").notNull(),
  date: timestamp("date").defaultNow(),
});

export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // Cafe, Duty Free, Wi-Fi, Seat Selection, Lounge, Eco Products
  pointsRequired: integer("points_required").notNull(),
  description: text("description").notNull(),
  discountValue: text("discount_value").notNull(),
  imageUrl: text("image_url").notNull(),
  tierRequirement: text("tier_requirement").notNull().default("Bronze"),
  stock: integer("stock").notNull().default(100),
});

export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  rewardId: integer("reward_id").notNull(),
  voucherCode: text("voucher_code").notNull(),
  status: text("status").notNull().default("Active"), // Active, Used, Expired
  redeemedAt: timestamp("redeemed_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  bonusPoints: integer("bonus_points").notNull(),
  category: text("category").notNull(),
  iconName: text("icon_name").notNull(),
  targetCount: integer("target_count").notNull(),
});

export const userChallenges = pgTable("user_challenges", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  challengeId: integer("challenge_id").notNull(),
  currentProgress: integer("current_progress").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  claimedAt: timestamp("claimed_at"),
});

export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(),
});

export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  badgeId: integer("badge_id").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // points, reward, tier, challenge, system
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const partnerAirports = pgTable("partner_airports", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  city: text("city").notNull(),
  country: text("country").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  rating: real("rating").notNull().default(4.8),
  greenFeatures: text("green_features").notNull(), // comma separated list
});

export const partnerAirlines = pgTable("partner_airlines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  hubAirport: text("hub_airport").notNull(),
  bonusMultiplier: real("bonus_multiplier").notNull().default(1.5),
  ecoCertified: boolean("eco_certified").notNull().default(true),
});
