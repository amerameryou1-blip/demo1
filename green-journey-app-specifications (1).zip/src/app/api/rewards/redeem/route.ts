import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, rewards, userRewards, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { rewardId } = await req.json();
    const userId = "demo-user-1";

    // Fetch user and reward
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const [reward] = await db.select().from(rewards).where(eq(rewards.id, Number(rewardId)));

    if (!user) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 });
    }

    if (!reward) {
      return NextResponse.json({ success: false, error: "Reward not found" }, { status: 404 });
    }

    if (user.greenPoints < reward.pointsRequired) {
      return NextResponse.json(
        { success: false, error: `Insufficient points. Required: ${reward.pointsRequired}, Available: ${user.greenPoints}` },
        { status: 400 }
      );
    }

    // Deduct points
    const remainingPoints = user.greenPoints - reward.pointsRequired;
    await db.update(users).set({ greenPoints: remainingPoints }).where(eq(users.id, userId));

    // Generate Voucher
    const randomCode = `GJ-${reward.category.substring(0, 3).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 90); // 90 days validity

    const [newVoucher] = await db
      .insert(userRewards)
      .values({
        userId,
        rewardId: reward.id,
        voucherCode: randomCode,
        status: "Active",
        redeemedAt: new Date(),
        expiresAt,
      })
      .returning();

    // Notify user
    await db.insert(notifications).values({
      userId,
      title: "Reward Redeemed Successfully!",
      message: `You redeemed "${reward.title}" for ${reward.pointsRequired} Green Points. Your digital voucher code is ${randomCode}.`,
      type: "reward",
      read: false,
    });

    return NextResponse.json({
      success: true,
      voucher: newVoucher,
      reward,
      remainingPoints,
    });
  } catch (error: any) {
    console.error("POST /api/rewards/redeem error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
