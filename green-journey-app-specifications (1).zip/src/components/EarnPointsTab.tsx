"use client";

import React, { useState } from "react";
import {
  QrCode,
  CheckCircle2,
  Calendar,
  Search,
  Filter,
  PlusCircle,
  Leaf,
  Plane,
  Receipt,
  Droplet,
  Train,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

interface EarnPointsTabProps {
  actions: any[];
  onOpenVerification: () => void;
  onLogQuickAction: (type: string, title: string) => void;
}

export default function EarnPointsTab({ actions, onOpenVerification, onLogQuickAction }: EarnPointsTabProps) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [showLogModal, setShowLogModal] = useState(false);
  const [customTitle, setCustomTitle] = useState("");
  const [customCategory, setCustomCategory] = useState("Digital Boarding Pass");

  const categories = [
    "All",
    "Digital Boarding Pass",
    "Verified Carbon Offset",
    "Hydration Station",
    "Digital Receipt",
    "Airport Rail Transit",
    "Mobile Check-in",
  ];

  const filteredActions = actions.filter((act) => {
    const matchesCat = selectedCategory === "All" || act.category === selectedCategory;
    const matchesQuery =
      act.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      act.referenceNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (act.airportCode && act.airportCode.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesQuery;
  });

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle) return;
    const typeMap: Record<string, string> = {
      "Digital Boarding Pass": "boarding_pass",
      "Verified Carbon Offset": "carbon_offset",
      "Hydration Station": "hydration",
      "Digital Receipt": "digital_receipt",
      "Airport Rail Transit": "rail_transit",
      "Mobile Check-in": "mobile_checkin",
    };
    onLogQuickAction(typeMap[customCategory] || "boarding_pass", customTitle);
    setCustomTitle("");
    setShowLogModal(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner & Verification Scanner Trigger */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/60 to-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Instant Flight & Airport Verification</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Earn Green Points</h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Every eco-choice made in transit adds verified Green Points directly to your balance. Scan barcodes or upload digital passes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenVerification}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition transform active:scale-95 cursor-pointer"
          >
            <QrCode className="w-4 h-4" />
            <span>Open QR Live Scanner</span>
          </button>

          <button
            onClick={() => setShowLogModal(true)}
            className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center gap-2 transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-emerald-400" />
            <span>Manual Entry</span>
          </button>
        </div>
      </div>

      {/* Action Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <p className="text-[11px] text-slate-400 font-medium uppercase">Verified Actions</p>
          <p className="text-2xl font-black text-white">{actions.length}</p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <p className="text-[11px] text-slate-400 font-medium uppercase">Total Earned</p>
          <p className="text-2xl font-black text-emerald-400">
            +{actions.reduce((acc, a) => acc + (a.pointsEarned || 0), 0)} PTS
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <p className="text-[11px] text-slate-400 font-medium uppercase">Carbon Footprint Saved</p>
          <p className="text-2xl font-black text-blue-400">
            {actions.reduce((acc, a) => acc + (a.co2OffsetKg || 0), 0).toFixed(1)} kg
          </p>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <p className="text-[11px] text-slate-400 font-medium uppercase">Paper Sheets Saved</p>
          <p className="text-2xl font-black text-amber-400">
            {actions.filter((a) => a.category.includes("Digital")).length * 3} Pages
          </p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search reference #, airport code or action..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition cursor-pointer whitespace-nowrap ${
                  selectedCategory === cat
                    ? "bg-emerald-500 text-slate-950 font-bold shadow"
                    : "bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Verified Actions Table/Feed */}
      <div className="space-y-3">
        {filteredActions.length === 0 ? (
          <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
            <Leaf className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-base font-bold text-white">No Verified Actions Found</p>
            <p className="text-xs text-slate-400">Try adjusting your filters or scan a new boarding pass QR code.</p>
          </div>
        ) : (
          filteredActions.map((action) => (
            <div
              key={action.id}
              className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start sm:items-center gap-3">
                <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0">
                  {action.category.includes("Boarding") ? (
                    <Plane className="w-5 h-5" />
                  ) : action.category.includes("Receipt") ? (
                    <Receipt className="w-5 h-5" />
                  ) : action.category.includes("Hydration") ? (
                    <Droplet className="w-5 h-5" />
                  ) : action.category.includes("Transit") ? (
                    <Train className="w-5 h-5" />
                  ) : (
                    <Leaf className="w-5 h-5" />
                  )}
                </div>

                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-bold text-white truncate">{action.title}</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-[10px] font-semibold text-emerald-400">
                      {action.category}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-[10px] font-bold text-blue-300">
                      Ref: {action.referenceNo}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      {new Date(action.date).toLocaleDateString()}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-400 font-medium">{action.co2OffsetKg} kg CO₂ Reduced</span>
                    <span>•</span>
                    <span className="text-slate-300 font-semibold">{action.airportCode || "DXB"} Hub</span>
                  </div>
                </div>
              </div>

              {/* Status & Points Tag */}
              <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  {action.status}
                </span>

                <span className="text-base font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20">
                  +{action.pointsEarned} PTS
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Manual Action Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl text-white space-y-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-emerald-400" />
              Log Green Passenger Action
            </h2>

            <form onSubmit={handleCustomSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium">Category</label>
                <select
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 transition"
                >
                  <option value="Digital Boarding Pass">Digital Boarding Pass (+150 Pts)</option>
                  <option value="Verified Carbon Offset">Verified Carbon Offset (+300 Pts)</option>
                  <option value="Hydration Station">Hydration Station Water Refill (+30 Pts)</option>
                  <option value="Digital Receipt">Duty Free Digital Receipt (+45 Pts)</option>
                  <option value="Airport Rail Transit">Airport EV/Rail Transit (+90 Pts)</option>
                  <option value="Mobile Check-in">Paperless Mobile Check-in (+60 Pts)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium">Flight or Action Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Flight EK-201 DXB to JFK Digital Pass"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow transition cursor-pointer"
                >
                  Verify & Award Points
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
