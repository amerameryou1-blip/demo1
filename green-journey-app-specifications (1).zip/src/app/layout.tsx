import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Green Journey App — Rewarding Sustainable Travel",
  description: "The luxury eco-loyalty platform connecting frequent flyers with airlines, partner airport lounges, and sustainable aviation fuel rewards.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
