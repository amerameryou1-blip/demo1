import { db } from "./index";
import {
  users,
  airlineAccounts,
  verifiedActions,
  rewards,
  challenges,
  badges,
  notifications,
  partnerAirports,
  partnerAirlines,
  userChallenges,
  userBadges,
} from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // Check if seeded
    const existingUsers = await db.select().from(users).where(eq(users.id, "demo-user-1"));
    if (existingUsers.length > 0) {
      return; // Already seeded
    }

    // Insert Default User
    await db.insert(users).values({
      id: "demo-user-1",
      name: "Captain Sarah Jenkins",
      email: "sarah.jenkins@greenjourney.com",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
      tier: "Silver",
      greenPoints: 2850,
      co2SavedKg: 142.5,
      waterSavedLiters: 320,
      plasticAvoidedCount: 48,
      homeAirport: "DXB - Dubai International",
      frequentFlyerId: "GJ-9824106",
    });

    // Linked Airlines
    await db.insert(airlineAccounts).values([
      {
        userId: "demo-user-1",
        airlineName: "Emirates Skywards",
        airlineCode: "EK",
        accountNumber: "EK-882049112",
        status: "Connected",
        pointsSynced: 1450,
      },
      {
        userId: "demo-user-1",
        airlineName: "Qatar Privilege Club",
        airlineCode: "QR",
        accountNumber: "QR-9018423",
        status: "Connected",
        pointsSynced: 800,
      },
      {
        userId: "demo-user-1",
        airlineName: "Singapore Airlines KrisFlyer",
        airlineCode: "SQ",
        accountNumber: "SQ-4491028",
        status: "Connected",
        pointsSynced: 600,
      },
    ]);

    // Verified Actions
    await db.insert(verifiedActions).values([
      {
        userId: "demo-user-1",
        title: "Digital Boarding Pass - DXB to LHR",
        category: "Digital Boarding Pass",
        pointsEarned: 150,
        co2OffsetKg: 25.0,
        status: "Verified",
        airportCode: "DXB",
        referenceNo: "GJ-BP-8819",
        date: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 hours ago
      },
      {
        userId: "demo-user-1",
        title: "Verified SAF Carbon Offset Purchase",
        category: "Verified Carbon Offset",
        pointsEarned: 350,
        co2OffsetKg: 85.0,
        status: "Verified",
        airportCode: "DXB",
        referenceNo: "GJ-CO2-9901",
        date: new Date(Date.now() - 1000 * 60 * 60 * 28), // Yesterday
      },
      {
        userId: "demo-user-1",
        title: "Refilled Reusable Bottle at Gate B14",
        category: "Hydration Station",
        pointsEarned: 25,
        co2OffsetKg: 0.5,
        status: "Verified",
        airportCode: "DXB",
        referenceNo: "GJ-HYD-1022",
        date: new Date(Date.now() - 1000 * 60 * 60 * 32),
      },
      {
        userId: "demo-user-1",
        title: "Paperless Duty Free Digital Receipt",
        category: "Digital Receipt",
        pointsEarned: 40,
        co2OffsetKg: 1.2,
        status: "Verified",
        airportCode: "DXB",
        referenceNo: "GJ-REC-4410",
        date: new Date(Date.now() - 1000 * 60 * 60 * 48),
      },
      {
        userId: "demo-user-1",
        title: "Electric Rail Express to Terminal",
        category: "Airport Rail Transit",
        pointsEarned: 80,
        co2OffsetKg: 8.5,
        status: "Verified",
        airportCode: "LHR",
        referenceNo: "GJ-TR-6602",
        date: new Date(Date.now() - 1000 * 60 * 60 * 72),
      },
      {
        userId: "demo-user-1",
        title: "Mobile Pre-flight App Check-in",
        category: "Mobile Check-in",
        pointsEarned: 50,
        co2OffsetKg: 2.0,
        status: "Verified",
        airportCode: "SIN",
        referenceNo: "GJ-MC-1109",
        date: new Date(Date.now() - 1000 * 60 * 60 * 96),
      },
    ]);

    // Rewards
    await db.insert(rewards).values([
      {
        title: "20% off Gourmet Airport Organic Café",
        category: "Café",
        pointsRequired: 300,
        description: "Enjoy sustainable, locally sourced organic dining at participating terminal lounges and cafes.",
        discountValue: "20% OFF",
        imageUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Bronze",
        stock: 500,
      },
      {
        title: "High-Speed In-Flight Wi-Fi Flight Pass",
        category: "In-flight Wi-Fi",
        pointsRequired: 800,
        description: "Unlimited streaming and messaging connection on all short and long-haul partner flights.",
        discountValue: "FREE PASS",
        imageUrl: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Bronze",
        stock: 250,
      },
      {
        title: "Extra Legroom Preferred Seat Upgrade",
        category: "Seat Selection",
        pointsRequired: 1200,
        description: "Reserve front row or exit row extra legroom seats with eco-leather ergonomic comfort.",
        discountValue: "FREE UPGRADE",
        imageUrl: "https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Silver",
        stock: 120,
      },
      {
        title: "15% Eco-Friendly Duty Free Voucher",
        category: "Duty-free discounts",
        pointsRequired: 500,
        description: "Save on sustainable cosmetics, recycled travel items, and certified zero-emission perfume lines.",
        discountValue: "15% OFF",
        imageUrl: "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Bronze",
        stock: 400,
      },
      {
        title: "VIP First Class Green Lounge Access Pass",
        category: "Lounge discounts",
        pointsRequired: 2200,
        description: "Access tranquil, zero-single-use-plastic flagship VIP airport lounges worldwide with complimentary organic buffet.",
        discountValue: "VIP PASS",
        imageUrl: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Gold",
        stock: 80,
      },
      {
        title: "Recycled Ocean Plastics Travel Toiletry Kit",
        category: "Eco-friendly products",
        pointsRequired: 1500,
        description: "Premium flight accessory set constructed from upcycled ocean polymer with biodegradable amenities.",
        discountValue: "100% REDEEM",
        imageUrl: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Silver",
        stock: 150,
      },
      {
        title: "Direct SAF Aviation Fuel Carbon Offset Offset Token",
        category: "Carbon Offset",
        pointsRequired: 1000,
        description: "Directly sponsor 100kg of Sustainable Aviation Fuel (SAF) into partner airport fueling systems.",
        discountValue: "100kg SAF",
        imageUrl: "https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?auto=format&fit=crop&q=80&w=600",
        tierRequirement: "Bronze",
        stock: 1000,
      },
    ]);

    // Challenges
    const insertedChallenges = await db
      .insert(challenges)
      .values([
        {
          title: "Plastic-Free Traveler",
          description: "Skip single-use cups and plastic bags on 3 consecutive flights using reusable bottles and digital passes.",
          bonusPoints: 300,
          category: "Waste Elimination",
          iconName: "Droplets",
          targetCount: 3,
        },
        {
          title: "100% Digital Traveler",
          description: "Use zero printed paper passes, tags, or invoices across 5 journeys.",
          bonusPoints: 500,
          category: "Paperless Flight",
          iconName: "Smartphone",
          targetCount: 5,
        },
        {
          title: "Green Explorer Extraordinaire",
          description: "Offset 100% carbon footprint and fly with eco-certified partner airlines on 3 multi-leg trips.",
          bonusPoints: 750,
          category: "Carbon Offset",
          iconName: "Globe",
          targetCount: 3,
        },
        {
          title: "Zero-Emission Transit Pioneer",
          description: "Arrive at participating airports via high-speed electric rail or EV shuttle 4 times.",
          bonusPoints: 400,
          category: "Ground Transit",
          iconName: "Train",
          targetCount: 4,
        },
      ])
      .returning();

    // Challenge user progress
    if (insertedChallenges.length > 0) {
      await db.insert(userChallenges).values([
        {
          userId: "demo-user-1",
          challengeId: insertedChallenges[0].id,
          currentProgress: 2,
          completed: false,
        },
        {
          userId: "demo-user-1",
          challengeId: insertedChallenges[1].id,
          currentProgress: 5,
          completed: true,
          claimedAt: new Date(Date.now() - 86400000 * 3),
        },
        {
          userId: "demo-user-1",
          challengeId: insertedChallenges[2].id,
          currentProgress: 1,
          completed: false,
        },
        {
          userId: "demo-user-1",
          challengeId: insertedChallenges[3].id,
          currentProgress: 3,
          completed: false,
        },
      ]);
    }

    // Badges
    const insertedBadges = await db
      .insert(badges)
      .values([
        {
          name: "Eco Aviator First Class",
          description: "Achieved Silver Sustainability Tier with over 2,500 Green Points.",
          icon: "Award",
          category: "Tier Milestones",
        },
        {
          name: "Paperless Pioneer",
          description: "Scanned digital boarding pass and mobile receipts for 10 straight trips.",
          icon: "QrCode",
          category: "Digital Transit",
        },
        {
          name: "Zero Single-Use Warrior",
          description: "Eliminated plastic bottle usage at 5 major international hubs.",
          icon: "ShieldCheck",
          category: "Eco Living",
        },
        {
          name: "SAF Backer",
          description: "Sponsored over 100kg of Sustainable Aviation Fuel contributions.",
          icon: "Leaf",
          category: "Climate Action",
        },
        {
          name: "Global Hub Explorer",
          description: "Utilized green airport features across 3 continents.",
          icon: "Compass",
          category: "Exploration",
        },
      ])
      .returning();

    // User badges
    if (insertedBadges.length > 0) {
      await db.insert(userBadges).values([
        { userId: "demo-user-1", badgeId: insertedBadges[0].id },
        { userId: "demo-user-1", badgeId: insertedBadges[1].id },
        { userId: "demo-user-1", badgeId: insertedBadges[2].id },
      ]);
    }

    // Notifications
    await db.insert(notifications).values([
      {
        userId: "demo-user-1",
        title: "You earned 150 Green Points!",
        message: "Digital boarding pass DXB -> LHR successfully verified. +25kg CO2 offset calculated.",
        type: "points",
        read: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
      },
      {
        userId: "demo-user-1",
        title: "New Premium Reward Available!",
        message: "VIP First Class Green Lounge pass is now unlocked for your account.",
        type: "reward",
        read: false,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
      },
      {
        userId: "demo-user-1",
        title: "Tier Progress Alert",
        message: "Only 1,150 Green Points left until reaching Gold Tier privileges!",
        type: "tier",
        read: true,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24),
      },
      {
        userId: "demo-user-1",
        title: "Challenge Complete: 100% Digital Traveler",
        message: "Congratulations! You claimed +500 bonus Green Points for going paperless.",
        type: "challenge",
        read: true,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72),
      },
    ]);

    // Partner Airports
    await db.insert(partnerAirports).values([
      {
        name: "Dubai International Airport",
        code: "DXB",
        city: "Dubai",
        country: "United Arab Emirates",
        lat: 25.2532,
        lng: 55.3657,
        rating: 4.9,
        greenFeatures: "100% Solar-Powered Concourse B, Free Organic Hydration Stations, Electric Monorail, Zero Waste Lounges",
      },
      {
        name: "Hamad International Airport",
        code: "DOH",
        city: "Doha",
        country: "Qatar",
        lat: 25.2609,
        lng: 51.6138,
        rating: 4.9,
        greenFeatures: "Tropical Indoor Forest Biome, High Efficiency Water Recycling, Paperless Smart Gates, EV Apron Fleet",
      },
      {
        name: "Singapore Changi Airport",
        code: "SIN",
        city: "Singapore",
        country: "Singapore",
        lat: 1.3644,
        lng: 103.9915,
        rating: 5.0,
        greenFeatures: "Rain Vortex Recycled Water Canopy, Solar Roof Array, SAF Fuel Pipeline Direct, Butterfly Eco Garden",
      },
      {
        name: "London Heathrow Airport",
        code: "LHR",
        city: "London",
        country: "United Kingdom",
        lat: 51.47,
        lng: -0.4543,
        rating: 4.7,
        greenFeatures: "Heathrow Express Zero Emissions Rail, SAF Terminal Hub, Single-use Plastic Ban, Smart HVAC Efficiency",
      },
      {
        name: "John F. Kennedy International",
        code: "JFK",
        city: "New York",
        country: "United States",
        lat: 40.6413,
        lng: -73.7781,
        rating: 4.6,
        greenFeatures: "New Solar Terminal 6 Microgrid, Rainwater Capture, Electric Airside Vehicles, Digital Touchpoints",
      },
      {
        name: "Tokyo Haneda Airport",
        code: "HND",
        city: "Tokyo",
        country: "Japan",
        lat: 35.5494,
        lng: 139.7798,
        rating: 4.9,
        greenFeatures: "Hydrogen Shuttle Buses, High-Speed Railway Hub Link, Zero Single-Use Packaging Lounges",
      },
      {
        name: "Paris Charles de Gaulle",
        code: "CDG",
        city: "Paris",
        country: "France",
        lat: 49.0097,
        lng: 2.5479,
        rating: 4.6,
        greenFeatures: "Geothermal Heating System, TGV High-Speed Rail Integration, Organic Waste Composting Station",
      },
      {
        name: "Frankfurt Airport",
        code: "FRA",
        city: "Frankfurt",
        country: "Germany",
        lat: 50.0379,
        lng: 8.5622,
        rating: 4.8,
        greenFeatures: "Solar Farm Runway Extension, Intercity Rail Station Hub, SAF Delivery Tank System",
      },
    ]);

    // Partner Airlines
    await db.insert(partnerAirlines).values([
      {
        name: "Emirates",
        code: "EK",
        hubAirport: "DXB",
        bonusMultiplier: 1.5,
        ecoCertified: true,
      },
      {
        name: "Qatar Airways",
        code: "QR",
        hubAirport: "DOH",
        bonusMultiplier: 1.5,
        ecoCertified: true,
      },
      {
        name: "Singapore Airlines",
        code: "SQ",
        hubAirport: "SIN",
        bonusMultiplier: 1.5,
        ecoCertified: true,
      },
      {
        name: "British Airways",
        code: "BA",
        hubAirport: "LHR",
        bonusMultiplier: 1.3,
        ecoCertified: true,
      },
      {
        name: "Lufthansa",
        code: "LH",
        hubAirport: "FRA",
        bonusMultiplier: 1.4,
        ecoCertified: true,
      },
      {
        name: "Delta Air Lines",
        code: "DL",
        hubAirport: "JFK",
        bonusMultiplier: 1.2,
        ecoCertified: true,
      },
    ]);

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Seeding error:", error);
  }
}
