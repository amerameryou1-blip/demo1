"use client";

import React from "react";
import { Leaf, Plane, Bell, Settings, Award, Sparkles, Smartphone, Monitor } from "lucide-react";

interface HeaderNavProps {
  user: any;
  unreadCount: number;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  onOpenAuth: () => void;
  isMobileFrame: boolean;
  onToggleFrame: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function HeaderNav({
  user,
  unreadCount,
  onOpenNotifications,
  onOpenSettings,
  onOpenAuth,
  isMobileFrame,
  onToggleFrame,
  activeTab,
  setActiveTab,
}: HeaderNavProps) {
  const tierColors: Record<string, string> = {
    Bronze: "from-amber-700 to-amber-900 border-amber-600 text-amber-200",
    Silver: "from-slate-400 via-slate-200 to-slate-500 border-slate-300 text-slate-900",
    Gold: "from-amber-300 via-yellow-400 to-amber-600 border-yellow-200 text-slate-950",
    Platinum: "from-cyan-300 via-slate-100 to-blue-500 border-cyan-200 text-slate-950",
  };

  const currentTierClass = tierColors[user?.tier || "Silver"] || tierColors.Silver;

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-xl border-b border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Logo */}
        <button
          onClick={() => setActiveTab("home")}
          className="flex items-center gap-3 group text-left cursor-pointer"
        >
          <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-blue-600 p-0.5 shadow-lg shadow-emerald-500/15 group-hover:scale-105 transition">
            <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center relative overflow-hidden">
              <Leaf className="w-5 h-5 text-emerald-400 absolute -translate-x-0.5 -translate-y-0.5" />
              <Plane className="w-5 h-5 text-blue-300 translate-x-1 translate-y-1 transform -rotate-12 opacity-80" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-300 bg-clip-text text-transparent">
                Green Journey
              </span>
            </div>
            <p className="text-[10px] text-emerald-400 font-medium tracking-wide">Airline Eco Rewards</p>
          </div>
        </button>

        {/* Desktop Tabs Quick Nav */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-950/80 p-1 rounded-2xl border border-slate-800">
          {[
            { id: "home", label: "Dashboard" },
            { id: "earn", label: "Earn Points" },
            { id: "verify", label: "Verify QR" },
            { id: "rewards", label: "Rewards" },
            { id: "challenges", label: "Challenges" },
            { id: "impact", label: "My Impact" },
            { id: "map", label: "Airports Map" },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-xl transition cursor-pointer ${
                activeTab === item.id
                  ? "bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20"
                  : "text-slate-300 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right User Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile Frame Toggle */}
          <button
            onClick={onToggleFrame}
            title={isMobileFrame ? "Switch to Desktop Layout" : "Switch to Android App Preview"}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 text-emerald-300 text-xs font-semibold border border-emerald-500/30 transition cursor-pointer shadow"
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span className="text-xs">{isMobileFrame ? "Web View" : "Android App View"}</span>
          </button>

          {/* Points Pill */}
          <button
            onClick={() => setActiveTab("rewards")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-950/80 to-teal-950/80 border border-emerald-500/30 hover:border-emerald-400 text-xs font-semibold text-white shadow-inner transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="font-bold text-emerald-300">{user?.greenPoints?.toLocaleString() || 2850}</span>
            <span className="text-[10px] text-slate-300 font-normal uppercase">Pts</span>
          </button>

          {/* Tier Badge Pill */}
          <button
            onClick={onOpenAuth}
            className={`px-2.5 py-1 rounded-full bg-gradient-to-r ${currentTierClass} border text-[11px] font-extrabold uppercase tracking-wider flex items-center gap-1 shadow-md hover:scale-105 transition cursor-pointer`}
          >
            <Award className="w-3 h-3 shrink-0" />
            <span>{user?.tier || "Silver"}</span>
          </button>

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-slate-950 font-bold text-[10px] rounded-full flex items-center justify-center animate-pulse shadow">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
