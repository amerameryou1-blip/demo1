"use client";

import React from "react";
import {
  Sparkles,
  Award,
  ArrowUpRight,
  QrCode,
  Gift,
  Leaf,
  Globe,
  TrendingUp,
  CheckCircle2,
  Plane,
  ChevronRight,
  Zap,
  ShieldCheck,
  Droplet,
  ChevronUp,
  Smartphone,
} from "lucide-react";

interface HomeDashboardProps {
  user: any;
  actions: any[];
  challenges: any[];
  userChallenges: any[];
  setActiveTab: (tab: string) => void;
  onOpenVerification: () => void;
  onCompleteMission: (missionTitle: string, pts: number) => void;
}

export default function HomeDashboard({
  user,
  actions,
  challenges,
  userChallenges,
  setActiveTab,
  onOpenVerification,
  onCompleteMission,
}: HomeDashboardProps) {
  // Tier Calculations
  const points = user?.greenPoints || 2850;
  const currentTier = user?.tier || "Silver";

  let nextTier = "Gold";
  let minPoints = 1500;
  let maxPoints = 3500;

  if (currentTier === "Bronze") {
    nextTier = "Silver";
    minPoints = 0;
    maxPoints = 1500;
  } else if (currentTier === "Silver") {
    nextTier = "Gold";
    minPoints = 1500;
    maxPoints = 3500;
  } else if (currentTier === "Gold") {
    nextTier = "Platinum";
    minPoints = 3500;
    maxPoints = 7500;
  } else {
    nextTier = "Platinum Elite";
    minPoints = 7500;
    maxPoints = 15000;
  }

  const progressPct = Math.min(100, Math.max(0, Math.round(((points - minPoints) / (maxPoints - minPoints)) * 100)));
  const pointsToNext = Math.max(0, maxPoints - points);

  // Daily Quests State
  const dailyMissions = [
    {
      id: "m1",
      title: "Mobile App Flight Check-in",
      points: 50,
      description: "Complete paperless mobile check-in before arrival",
      category: "Digital Transit",
      completed: true,
    },
    {
      id: "m2",
      title: "Airport Hydration Refill",
      points: 25,
      description: "Refill reusable water bottle at Terminal hydration pod",
      category: "Zero Waste",
      completed: false,
    },
    {
      id: "m3",
      title: "Paperless Duty Free Invoice",
      points: 40,
      description: "Opt for digital email receipt at duty free shops",
      category: "Digital Transit",
      completed: false,
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/80 border border-slate-800 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Verified Eco Passenger • ID: {user?.frequentFlyerId || "GJ-9824106"}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Welcome back, {user?.name || "Captain Sarah"} ✈️
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Your eco journeys have offset <strong className="text-emerald-300">{user?.co2SavedKg || 142.5} kg CO₂</strong> across 6 flights. Keep collecting points for Gold Tier lounge privileges!
            </p>
          </div>

          <button
            onClick={onOpenVerification}
            className="self-start sm:self-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center gap-2 transition transform active:scale-95 cursor-pointer shrink-0"
          >
            <QrCode className="w-4 h-4" />
            <span>Verify Boarding Pass</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Points Balance & Tier Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Green Points Balance Glass Card */}
        <div className="relative overflow-hidden rounded-3xl bg-slate-900/90 border border-emerald-500/30 p-6 shadow-xl flex flex-col justify-between group hover:border-emerald-500/50 transition">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Green Points Balance
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-black text-white tracking-tight">
                  {points.toLocaleString()}
                </span>
                <span className="text-sm font-semibold text-emerald-400">PTS</span>
              </div>
            </div>

            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Leaf className="w-6 h-6" />
            </div>
          </div>

          <p className="text-xs text-slate-400 pt-4 border-t border-slate-800/80">
            Equivalent to offsetting <span className="text-emerald-300 font-semibold">{Math.round(points * 0.05)} kg</span> of aviation CO₂ or 14 full single-use plastic neutral flight trips.
          </p>

          <div className="flex items-center gap-3 pt-4">
            <button
              onClick={() => setActiveTab("rewards")}
              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition shadow cursor-pointer"
            >
              <Gift className="w-4 h-4" />
              <span>Redeem Rewards</span>
            </button>
            <button
              onClick={() => setActiveTab("earn")}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center justify-center gap-1 transition cursor-pointer"
            >
              <span>View Earn History</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Card 2: Tier Status & Progress Bar */}
        <div className="relative overflow-hidden rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-400" /> Current Membership Level
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-black text-white tracking-tight">{currentTier} Tier</span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-[10px] font-bold">
                  Active Status
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Award className="w-7 h-7" />
            </div>
          </div>

          {/* Tier Bar Progress */}
          <div className="space-y-2 py-4">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-400">Progress to {nextTier} Tier</span>
              <span className="text-emerald-400 font-bold">{progressPct}%</span>
            </div>

            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 rounded-full transition-all duration-1000"
                style={{ width: `${progressPct}%` }}
              />
            </div>

            <p className="text-[11px] text-slate-400 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                Only <strong className="text-white">{pointsToNext.toLocaleString()} points</strong> left until {nextTier} level privileges!
              </span>
            </p>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span>Perks: 1.5x Multiplier • Lounge Passes • Free Wi-Fi</span>
            <button
              onClick={() => setActiveTab("profile")}
              className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 transition cursor-pointer"
            >
              <span>Details</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Android Native USB Debugging & APK Download Guide Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/80 border border-emerald-500/40 rounded-3xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Native Android Application Project Ready</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black">
                  APK / USB Debugging
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                Full Kotlin + Capacitor Android Studio project exported in <code className="text-emerald-400 font-mono">./android</code> directory
              </p>
            </div>
          </div>
        </div>

        <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-1 font-mono">
          <p className="text-emerald-400 font-bold font-sans">⚡ Quick Run on USB Debugged Android Phone:</p>
          <p>1. Connect Android Phone via USB with USB Debugging enabled</p>
          <p>2. Run command: <span className="text-white bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">cd android && ./gradlew assembleDebug</span></p>
          <p>3. Install APK: <span className="text-white bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">adb install app/build/outputs/apk/debug/app-debug.apk</span></p>
          <p className="text-slate-400 pt-1 font-sans">Or open <code className="text-emerald-300">./android</code> folder in Android Studio and press "Run on Device".</p>
        </div>
      </div>

      {/* Quick Action Buttons Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { id: "earn", title: "Earn Points", icon: Leaf, color: "from-emerald-500/20 to-teal-500/20 border-emerald-500/30 text-emerald-400" },
          { id: "rewards", title: "Rewards Marketplace", icon: Gift, color: "from-blue-500/20 to-indigo-500/20 border-blue-500/30 text-blue-400" },
          { id: "impact", title: "My Eco Impact", icon: TrendingUp, color: "from-amber-500/20 to-orange-500/20 border-amber-500/30 text-amber-400" },
          { id: "map", title: "Airports Map", icon: Globe, color: "from-teal-500/20 to-emerald-500/20 border-teal-500/30 text-teal-400" },
        ].map((btn) => {
          const Icon = btn.icon;
          return (
            <button
              key={btn.id}
              onClick={() => setActiveTab(btn.id)}
              className={`p-4 rounded-2xl bg-gradient-to-br ${btn.color} border hover:scale-[1.02] transition shadow-lg text-left flex items-center gap-3 cursor-pointer`}
            >
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{btn.title}</p>
                <p className="text-[10px] text-slate-300 font-medium">Explore →</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Two Column Section: Today's Sustainable Missions + Recent Verified Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Sustainable Missions */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                Today's Eco Quests
              </h2>
              <p className="text-xs text-slate-400">Complete quick daily flight tasks to earn extra Green Points</p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold">
              +115 PTS
            </span>
          </div>

          <div className="space-y-3">
            {dailyMissions.map((mission) => (
              <div
                key={mission.id}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 hover:border-slate-700 transition"
              >
                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white truncate">{mission.title}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-medium shrink-0">
                      +{mission.points} Pts
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate">{mission.description}</p>
                </div>

                {mission.completed ? (
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                  </span>
                ) : (
                  <button
                    onClick={() => onCompleteMission(mission.title, mission.points)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition shrink-0 cursor-pointer"
                  >
                    Claim
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Recent Verified Actions Log */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Recent Activity Log
              </h2>
              <p className="text-xs text-slate-400">Verified actions automatically credited to your pass</p>
            </div>
            <button
              onClick={() => setActiveTab("earn")}
              className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition cursor-pointer"
            >
              <span>See All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {actions.slice(0, 4).map((act: any) => (
              <div
                key={act.id}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <Plane className="w-4 h-4" />
                  </div>
                  <div className="space-y-0.5 min-w-0">
                    <p className="text-xs font-bold text-white truncate">{act.title}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>{act.airportCode}</span>
                      <span>•</span>
                      <span>{new Date(act.date).toLocaleDateString()}</span>
                      <span>•</span>
                      <span className="text-emerald-400">{act.co2OffsetKg}kg CO₂ offset</span>
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-extrabold text-emerald-400">+{act.pointsEarned} PTS</span>
                  <p className="text-[10px] text-slate-500">{act.status}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
