import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  airlineAccounts,
  verifiedActions,
  rewards,
  userRewards,
  challenges,
  userChallenges,
  badges,
  userBadges,
  notifications,
  partnerAirports,
  partnerAirlines,
} from "@/db/schema";
import { seedDatabase } from "@/db/seed";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    // Ensure seed data exists
    await seedDatabase();

    const userId = "demo-user-1";

    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const airlinesList = await db.select().from(airlineAccounts).where(eq(airlineAccounts.userId, userId));
    const actionsList = await db.select().from(verifiedActions).where(eq(verifiedActions.userId, userId)).orderBy(desc(verifiedActions.date));
    const rewardsList = await db.select().from(rewards);
    const userVouchers = await db.select().from(userRewards).where(eq(userRewards.userId, userId)).orderBy(desc(userRewards.redeemedAt));
    const challengesList = await db.select().from(challenges);
    const userChallengesList = await db.select().from(userChallenges).where(eq(userChallenges.userId, userId));
    const badgesList = await db.select().from(badges);
    const userBadgesList = await db.select().from(userBadges).where(eq(userBadges.userId, userId));
    const notificationsList = await db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
    const airportsList = await db.select().from(partnerAirports);
    const partnerAirlinesList = await db.select().from(partnerAirlines);

    return NextResponse.json({
      success: true,
      user: user || null,
      airlineAccounts: airlinesList,
      actions: actionsList,
      rewards: rewardsList,
      userRewards: userVouchers,
      challenges: challengesList,
      userChallenges: userChallengesList,
      badges: badgesList,
      userBadges: userBadgesList,
      notifications: notificationsList,
      partnerAirports: airportsList,
      partnerAirlines: partnerAirlinesList,
    });
  } catch (error: any) {
    console.error("GET /api/data error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
