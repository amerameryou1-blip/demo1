"use client";

import React, { useState } from "react";
import {
  Globe,
  MapPin,
  Plane,
  Star,
  CheckCircle2,
  Sparkles,
  Zap,
  Leaf,
  ShieldCheck,
  ChevronRight,
  Info,
} from "lucide-react";

interface AirportsMapTabProps {
  airports: any[];
  airlines: any[];
}

export default function AirportsMapTab({ airports, airlines }: AirportsMapTabProps) {
  const [selectedAirport, setSelectedAirport] = useState<any | null>(airports[0] || null);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/60 to-blue-950/80 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>Global Eco Flight Network</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Participating Airports & Airlines</h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Green Journey partner airports feature automated SAF pipelines, solar terminals, zero-single-use lounges, and instant QR verification.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-emerald-400 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" /> {airports.length} Global Hubs
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-blue-400 flex items-center gap-1.5">
            <Plane className="w-3.5 h-3.5" /> {airlines.length} Partner Airlines
          </span>
        </div>
      </div>

      {/* World Map Visualizer Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-emerald-400" />
            Interactive Partner Airport Map
          </h2>
          <span className="text-xs text-slate-400">Click an airport node to view eco infrastructure</span>
        </div>

        {/* Visual Map Canvas Representation */}
        <div className="relative w-full h-80 bg-slate-950 rounded-2xl border border-slate-800 p-4 overflow-hidden flex items-center justify-center group">
          {/* Subtle World Map Grid lines SVG */}
          <svg className="absolute inset-0 w-full h-full opacity-15 stroke-slate-700 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" strokeWidth="1" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid)" />
            {/* World outline curve simulation */}
            <path d="M 50,120 Q 200,80 350,150 T 700,100" fill="none" stroke="#10B981" strokeWidth="2" strokeDasharray="4 4" />
          </svg>

          {/* Interactive Airport Pins */}
          <div className="relative w-full h-full max-w-3xl">
            {airports.map((ap) => {
              // Convert lat/lng roughly to % coordinates for map display
              const xPct = Math.min(90, Math.max(10, ((ap.lng + 180) / 360) * 100));
              const yPct = Math.min(85, Math.max(15, ((90 - ap.lat) / 180) * 100));
              const isSelected = selectedAirport?.code === ap.code;

              return (
                <button
                  key={ap.code}
                  onClick={() => setSelectedAirport(ap)}
                  style={{ left: `${xPct}%`, top: `${yPct}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group/pin cursor-pointer focus:outline-none z-10"
                >
                  {/* Pulse Ping Effect */}
                  <span className="absolute -inset-2 rounded-full bg-emerald-400/30 animate-ping" />

                  {/* Pin Node */}
                  <div
                    className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1 transition shadow-lg ${
                      isSelected
                        ? "bg-emerald-400 text-slate-950 scale-125 ring-4 ring-emerald-500/30 z-20"
                        : "bg-slate-900 border border-emerald-500/40 text-white hover:bg-emerald-500 hover:text-slate-950"
                    }`}
                  >
                    <MapPin className="w-3 h-3 shrink-0" />
                    <span>{ap.code}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Airport Detail Drawer */}
        {selectedAirport && (
          <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/30 space-y-3 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-xs">
                    {selectedAirport.code}
                  </span>
                  <h3 className="text-base font-bold text-white">{selectedAirport.name}</h3>
                </div>
                <p className="text-xs text-slate-400">
                  {selectedAirport.city}, {selectedAirport.country}
                </p>
              </div>

              <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/30 self-start sm:self-auto">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>{selectedAirport.rating} Eco Rating</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Verified Sustainable Infrastructure Features:
              </span>
              <p className="text-xs text-emerald-300 font-medium leading-relaxed">
                {selectedAirport.greenFeatures}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Partner Airlines Gallery */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Plane className="w-5 h-5 text-emerald-400" />
              Partner Global Airlines
            </h2>
            <p className="text-xs text-slate-400">Fly with partner carriers to enjoy up to 1.5x Green Points multipliers</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {airlines.map((airline) => (
            <div
              key={airline.code}
              className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 transition space-y-3 shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-emerald-400 text-xs">
                    {airline.code}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">{airline.name}</h3>
                    <p className="text-[10px] text-slate-400">Hub: {airline.hubAirport}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                  {airline.bonusMultiplier}x PTS
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-slate-300 pt-2 border-t border-slate-800">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>IATA Eco-Certified Airline Protocol</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
