import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, airlineAccounts, notifications } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { type, email, name, airlineName, accountNumber } = body;
    const userId = "demo-user-1";

    if (type === "link_airline") {
      if (!airlineName || !accountNumber) {
        return NextResponse.json({ success: false, error: "Airline name and account number are required" }, { status: 400 });
      }

      // Check if already linked
      const existing = await db
        .select()
        .from(airlineAccounts)
        .where(and(eq(airlineAccounts.userId, userId), eq(airlineAccounts.airlineName, airlineName)));

      if (existing.length > 0) {
        return NextResponse.json({ success: false, error: "Airline account is already linked" }, { status: 400 });
      }

      const codeMap: Record<string, string> = {
        "Emirates Skywards": "EK",
        "Qatar Privilege Club": "QR",
        "Singapore Airlines KrisFlyer": "SQ",
        "British Airways Executive Club": "BA",
        "Lufthansa Miles & More": "LH",
        "Delta SkyMiles": "DL",
      };

      const code = codeMap[airlineName] || "AIR";

      const [newAccount] = await db
        .insert(airlineAccounts)
        .values({
          userId,
          airlineName,
          airlineCode: code,
          accountNumber,
          status: "Connected",
          pointsSynced: 500, // Bonus sign-up sync
        })
        .returning();

      // Give 200 bonus Green Points for linking account
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      if (user) {
        await db.update(users).set({ greenPoints: user.greenPoints + 200 }).where(eq(users.id, userId));
      }

      await db.insert(notifications).values({
        userId,
        title: `${airlineName} Account Linked!`,
        message: `Your loyalty account ${accountNumber} is connected. You earned 200 bonus Green Points!`,
        type: "system",
        read: false,
      });

      return NextResponse.json({ success: true, account: newAccount });
    }

    if (type === "unlink_airline") {
      const { accountId } = body;
      await db.delete(airlineAccounts).where(eq(airlineAccounts.id, Number(accountId)));
      return NextResponse.json({ success: true });
    }

    if (type === "google" || type === "apple" || type === "login" || type === "signup") {
      // Simulate login or quick update
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      if (user) {
        await db
          .update(users)
          .set({
            name: name || user.name,
            email: email || user.email,
          })
          .where(eq(users.id, userId));
      }

      return NextResponse.json({ success: true, user: { ...user, name: name || user?.name, email: email || user?.email } });
    }

    return NextResponse.json({ success: false, error: "Invalid action type" }, { status: 400 });
  } catch (error: any) {
    console.error("POST /api/auth error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
